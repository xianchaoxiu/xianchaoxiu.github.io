import pytorch_lightning as pl
from matplotlib import pyplot as plt
import numpy as np
# %%
from cca_zoo.deepmodels import (
    DCCA,
    DTCCA,
    DCCAE,
    architectures,
    objectives,
)
from cca_zoo.deepmodels import architectures, objectives
import AllDatasetLoader as ADL
from torch.utils.data import DataLoader
from sklearn.manifold import TSNE
import torch

torch.set_float32_matmul_precision('medium')

train_set, val_set, test_set, view_1_shape, view_2_shape, view_3_shape = ADL.getThreeDigitViewsData(zoo=True)
view_1_shape = np.prod(view_1_shape)
view_2_shape = np.prod(view_2_shape)
view_3_shape = np.prod(view_3_shape)

print("view_1_shape:{}, view_2_shape:{}, view_3_shape:{}".format(view_1_shape, view_2_shape, view_3_shape))

latent_dims = 10
epochs = 1

batch_size = 1024
train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=False)
val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False, pin_memory=True, drop_last=False)
test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False, pin_memory=True, drop_last=False)

encoder_1 = architectures.Encoder(latent_dims=latent_dims, feature_size=view_1_shape, layer_sizes=(1024, 1024, 1024))
encoder_2 = architectures.Encoder(latent_dims=latent_dims, feature_size=view_2_shape, layer_sizes=(1024, 1024, 1024))
encoder_3 = architectures.Encoder(latent_dims=latent_dims, feature_size=view_3_shape, layer_sizes=(1024, 1024, 1024))


dcca = DTCCA(latent_dims=latent_dims, encoders=[encoder_1, encoder_2, encoder_3], r=1e-3, eps=1e-3)
trainer = pl.Trainer(
    max_epochs=epochs,
    enable_checkpointing=False,
    log_every_n_steps=1,
    accelerator='gpu',
    devices=1
)
trainer.fit(dcca, train_loader, val_loader)
Z_train = dcca.post_transform(train_loader, train=True)
Z_valid = dcca.post_transform(val_loader)
Z_test = dcca.post_transform(test_loader)

# mean of Z_train, Z_valid, Z_test
Z_train = np.mean(Z_train, axis=0)
Z_valid = np.mean(Z_valid, axis=0)
Z_test = np.mean(Z_test, axis=0)

# SVM classify
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score

clf = LinearSVC(C=0.01, dual=False)
clf.fit(Z_train, train_set.label)

# 预测和评估
train_pred = clf.predict(Z_train)
val_pred = clf.predict(Z_valid)
test_pred = clf.predict(Z_test)

train_acc = accuracy_score(train_set.label, train_pred)
valid_acc = accuracy_score(val_set.label, val_pred)
test_acc = accuracy_score(test_set.label, test_pred)

print(f"train, val, test: {train_acc}, {valid_acc}, {test_acc}")

# T-SNE of Z1
tsne = TSNE()
Z_tsne = tsne.fit_transform(Z_test)
# np.save("dcca_tsne_result.npy", Z_tsne)
# hide axis
fig = plt.figure(figsize=(12, 12))
ax = plt.axes(frameon=False)
plt.setp(ax, xticks=(), yticks=())

# add scatter plots for each class
classes = list(set(test_set.label.numpy().astype(int)))
scatter_plots = []  # list to hold scatter plot for each class
class_labels = []  # list to hold class labels
cmap = plt.cm.get_cmap('nipy_spectral', len(classes)) # 'nipy_spectral' is an example of colormap which can give more distinct colors
colors = cmap(np.linspace(0, 1, len(classes)))

for class_id, color in zip(classes, colors):
    idx = (test_set.label.numpy().astype(int) == class_id)  # get index of all points of this class
    scatter_plot = plt.scatter(Z_tsne[idx, 0], Z_tsne[idx, 1], color=color)
    scatter_plots.append(scatter_plot)
    class_labels.append(str(class_id))

# show legend with class labels
legend = plt.legend(scatter_plots, class_labels, loc='lower center',
                    bbox_to_anchor=(0.5, 1.05), shadow=False, scatterpoints=1, ncol=10)

# save figure
# plt.savefig('dcca_tsne_result.pdf', bbox_inches='tight', dpi=300, format='pdf')
plt.show()