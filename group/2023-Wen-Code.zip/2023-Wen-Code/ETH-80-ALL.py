import os
import glob
import numpy as np
import torch
from PIL import Image
import cv2
# 类别对应的目录名和标签
category_dir_to_label = {
    '1': ('apple', 1),
    '2': ('car', 2),
    '3': ('cow', 3),
    '4': ('cup', 4),
    '5': ('dog', 5),
    '6': ('horse', 6),
    '7': ('pear', 7),
    '8': ('tomato', 8),
}

# 数据存储
data_R = []
data_G = []
data_B = []
labels = []

# 遍历每个类别目录
for category_dir, (category_name, label) in category_dir_to_label.items():
    # 遍历每个图像文件
    for image_file in sorted(glob.glob(os.path.join('ETH-80-All', category_dir, '*.png'))):
        # 读取图像文件
        image = Image.open(image_file)

        img_array = np.array(image)

        # use cv2 to resize img to (64, 64)
        img_array = cv2.resize(img_array, (32, 32), interpolation=cv2.INTER_LINEAR)

        r, g, b = img_array[:, :, 0], img_array[:, :, 1], img_array[:, :, 2]

        # 添加到数据列表
        data_R.append(torch.from_numpy(r / 255.0).unsqueeze(0))
        data_G.append(torch.from_numpy(g / 255.0).unsqueeze(0))
        data_B.append(torch.from_numpy(b / 255.0).unsqueeze(0))
        labels.append(label)

# convert list to tensor
data_R = torch.stack(data_R, dim=0)
data_G = torch.stack(data_G, dim=0)
data_B = torch.stack(data_B, dim=0)
labels = torch.tensor(labels)

# shuffle data
indices = torch.randperm(len(labels))
data_R = data_R[indices]
data_G = data_G[indices]
data_B = data_B[indices]
labels = labels[indices]

# save .npy files
# np.save('./DataFiles/ETH-80-ALL-R.npy', data_R.numpy())
# np.save('./DataFiles/ETH-80-ALL-G.npy', data_G.numpy())
# np.save('./DataFiles/ETH-80-ALL-B.npy', data_B.numpy())
# np.save('./DataFiles/ETH-80-ALL-Label.npy', labels.numpy())

# save .pt files
torch.save(data_R, './DataFiles/ETH-80-ALL-R.pt')
torch.save(data_G, './DataFiles/ETH-80-ALL-G.pt')
torch.save(data_B, './DataFiles/ETH-80-ALL-B.pt')
torch.save(labels, './DataFiles/ETH-80-ALL-Label.pt')

print('Done!\n')