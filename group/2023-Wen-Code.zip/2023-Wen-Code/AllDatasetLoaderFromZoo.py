import numpy as np
from multiviewdata.torchdatasets import SplitMNIST, NoisyMNIST
from torch.utils.data import Subset

from cca_zoo.data.deep import get_dataloaders
import torch

def generateZooNoisyMNIST():
    train_dataset = NoisyMNIST(
        root="./DataZoo", mnist_type="FashionMNIST", train=True, download=True
    )
    test_dataset = NoisyMNIST(
        root="./DataZoo", mnist_type="FashionMNIST", train=False, download=True
    )

def getZooNoisyMNIST(n_train, n_val, batch_size=50, val_batch_size=10):

    train_dataset = NoisyMNIST(
            root="./DataZoo", mnist_type="MNIST", train=True, download=True
        )
    test_dataset = NoisyMNIST(
            root="./DataZoo", mnist_type="MNIST", train=False, download=True
        )
    val_dataset = Subset(train_dataset, np.arange(n_train, n_train + n_val))
    train_dataset = Subset(train_dataset, np.arange(n_train))
    # convert test_dataset to subset
    test_dataset = Subset(test_dataset, np.arange(10000))
    train_loader, val_loader = get_dataloaders(
        train_dataset, val_dataset, batch_size=batch_size, val_batch_size=val_batch_size
    )
    test_loader = get_dataloaders(
        test_dataset, batch_size=batch_size
    )
    X1_train = train_loader.collate_fn(
        [train_dataset.dataset[idx]["views"][0] for idx in train_dataset.indices]
    ).numpy()
    X2_train = train_loader.collate_fn(
        [train_dataset.dataset[idx]["views"][1] for idx in train_dataset.indices]
    ).numpy()
    y1_train = train_loader.collate_fn(
        [train_dataset.dataset[idx]["label"] for idx in train_dataset.indices]
    ).numpy()
    X1_valid = val_loader.collate_fn(
        [val_dataset.dataset[idx]["views"][0] for idx in val_dataset.indices]
    ).numpy()
    X2_valid = val_loader.collate_fn(
        [val_dataset.dataset[idx]["views"][1] for idx in val_dataset.indices]
    ).numpy()
    y1_valid = val_loader.collate_fn(
        [val_dataset.dataset[idx]["label"] for idx in val_dataset.indices]
    ).numpy()
    X1_test = test_loader.collate_fn(
        [test_dataset.dataset[idx]["views"][0] for idx in test_dataset.indices]
    ).numpy()
    X2_test = test_loader.collate_fn(
        [test_dataset.dataset[idx]["views"][1] for idx in test_dataset.indices]
    ).numpy()
    y1_test = test_loader.collate_fn(
        [test_dataset.dataset[idx]["label"] for idx in test_dataset.indices]
    ).numpy()
    y2_train = y1_train
    y2_valid = y1_valid
    y2_test = y1_test
    # convert to tensor
    # X1_train = torch.from_numpy(X1_train).float()
    # X2_train = torch.from_numpy(X2_train).float()
    # X1_valid = torch.from_numpy(X1_valid).float()
    # X2_valid = torch.from_numpy(X2_valid).float()
    # X1_test = torch.from_numpy(X1_test).float()
    # X2_test = torch.from_numpy(X2_test).float()
    # y1_train = torch.from_numpy(y1_train).float()
    # y2_train = torch.from_numpy(y2_train).float()
    # y1_valid = torch.from_numpy(y1_valid).float()
    # y2_valid = torch.from_numpy(y2_valid).float()
    # y1_test = torch.from_numpy(y1_test).float()
    # y2_test = torch.from_numpy(y2_test).float()
    return X1_train, X2_train, X1_valid, X2_valid, X1_test, X2_test, y1_train, y2_train, y1_valid, y2_valid, y1_test, y2_test


# X1_train, X2_train, X1_valid, X2_valid, X1_test, X2_test, \
#     y1_train, y2_train, y1_valid, y2_valid, y1_test, y2_test = \
#     getZooNoisyMNIST(50000, 10000, 1024, 1024)
#
# a = 0