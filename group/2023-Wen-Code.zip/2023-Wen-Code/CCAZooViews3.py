from sklearn.decomposition import PCA

from AllDatasetLoader import getCOIL100Data, getThreeDigitViewsData, getETH80Data, getETH80AllData
from cca_zoo.models import MCCA, GCCA, TCCA, KCCA, KGCCA, KTCCA, SCCA_PMD
import numpy as np
from matplotlib import font_manager
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import torch
# my_font = font_manager.FontProperties(fname='simsun.ttc', size=12)
# plt.rcParams['font.family'] = 'Times New Roman'
# plt.rcParams['axes.unicode_minus'] = False

train_set, val_set, test_set, view_1_shape, view_2_shape, view_3_shape = getETH80AllData(flatten=True)

latent_dims = 40
pca_dim = 400
pca_after = True
model_name = "MCCA3"
dataset_name = "ETH-80-All"
if pca_after:
    pca = PCA(n_components=pca_dim)
    pca.fit(train_set.view_1)
    train_set.view_1 = pca.transform(train_set.view_1)
    val_set.view_1 = pca.transform(val_set.view_1)
    test_set.view_1 = pca.transform(test_set.view_1)

    pca = PCA(n_components=pca_dim)
    pca.fit(train_set.view_2)
    train_set.view_2 = pca.transform(train_set.view_2)
    val_set.view_2 = pca.transform(val_set.view_2)
    test_set.view_2 = pca.transform(test_set.view_2)

    pca = PCA(n_components=pca_dim)
    pca.fit(train_set.view_3)
    train_set.view_3 = pca.transform(train_set.view_3)
    val_set.view_3 = pca.transform(val_set.view_3)
    test_set.view_3 = pca.transform(test_set.view_3)

X1_train = train_set.view_1
X2_train = train_set.view_2
X3_train = train_set.view_3

X1_test = test_set.view_1
X2_test = test_set.view_2
X3_test = test_set.view_3

mcca = MCCA(latent_dims=latent_dims).fit((X1_train, X2_train, X3_train))

Z1_train, Z2_train, Z3_train = mcca.transform((X1_train, X2_train, X3_train))
Z1_test, Z2_test, Z3_test = mcca.transform((X1_test, X2_test, X3_test))

Z_train = (Z1_train + Z2_train + Z3_train) / 3
Z_test = (Z1_test + Z2_test + Z3_test) / 3

train_label = train_set.label.numpy().astype(int)
test_label = test_set.label.numpy().astype(int)

# knn and svm

knn = KNeighborsClassifier(n_neighbors=1)
knn.fit(Z_train, train_label)
y_pred = knn.predict(Z_test)
knn_acc = accuracy_score(test_label, y_pred)

svm = SVC()
svm.fit(Z_train, train_label)
y_pred = svm.predict(Z_test)
svm_acc = accuracy_score(test_label, y_pred)

print(f"model:{model_name}, dataset:{dataset_name}, knn_acc:{knn_acc}, svm_acc:{svm_acc}")

# plot tsne

tsne = TSNE()
Z_tsne = tsne.fit_transform(Z_test)
fig = plt.figure(figsize=(14, 14))
ax = plt.axes(frameon=False)
plt.setp(ax, xticks=(), yticks=())

# add scatter plots for each class
classes = list(set(test_label))
scatter_plots = []  # list to hold scatter plot for each class
class_labels = []  # list to hold class labels
cmap = plt.colormaps.get_cmap('nipy_spectral') # 'nipy_spectral' is an example of colormap which can give more distinct colors
colors = cmap(np.linspace(0, 1, len(classes)))

for class_id, color in zip(classes, colors):
    idx = (test_label == class_id)  # get index of all points of this class
    # show bigger tsne points
    scatter_plot = plt.scatter(Z_tsne[idx, 0], Z_tsne[idx, 1], s=150, color=color, alpha=1.0)
    scatter_plots.append(scatter_plot)
    class_labels.append(str(class_id))

# show bigger legend with class labels

legend = plt.legend(scatter_plots, class_labels, loc='lower center',
                    bbox_to_anchor=(0.5, 1.05), shadow=False, scatterpoints=1, ncol=10, fontsize=32, markerscale=2.0)
# draw train_acc, valid_acc, test_acc in .4f on the bottom of the figure in big font size
# plt.text(0.5, -0.05, f"Unsupervised {model_name}, latent_dim:{latent_dims} \n"
#                      f"knn_acc:{knn_acc:.4f}, svm_acc:{svm_acc:.4f}",
#             horizontalalignment='center', verticalalignment='center', transform=ax.transAxes, fontsize=26)
# plt.text(0.5, -0.05, f"MCCA \n",
#             horizontalalignment='center', verticalalignment='center', transform=ax.transAxes, fontsize=26)

# save figure
# plt.savefig('dcca_tsne_result.pdf', bbox_inches='tight', dpi=300, format='pdf')
# plt.savefig(f"./Figures/{dataset_name}-Unsupervised-{model_name}-TSNE.png", bbox_inches='tight', dpi=300, format='png')
# plt.savefig(f"./Figures/{dataset_name}-Unsupervised-{model_name}-TSNE.pdf", bbox_inches='tight', dpi=300, format='pdf')
plt.show()
# save to .png file
# save to .pdf file
np.save(f"./Figures/{dataset_name}-Unsupervised-{model_name}-TSNE.npy", Z_tsne)
np.save(f"./Figures/{dataset_name}-Unsupervised-{model_name}-Label.npy", test_label)


