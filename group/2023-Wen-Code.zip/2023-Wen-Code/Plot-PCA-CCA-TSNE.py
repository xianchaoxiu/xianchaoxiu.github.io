import numpy as np
import matplotlib.pyplot as plt

# load data
pca_tsne = np.load("./Figures/NoisyMNIST-PCA-TSNE.npy")
cca_tsne = np.load("./Figures/NoisyMNIST-CCA-TSNE.npy")
label = np.load("./Figures/NoisyMNIST-PCA-CCA-Label.npy")


# plot tsne with bigger points and legend
fig = plt.figure(figsize=(24, 12))
ax = plt.axes(frameon=False)
plt.setp(ax, xticks=(), yticks=())

plt.subplot(1, 2, 1)
# hide subplot axis
plt.gca().set_axis_off()
classes = list(set(label))
scatter_plots = []  # list to hold scatter plot for each class
class_labels = []  # list to hold class labels
cmap = plt.cm.get_cmap('nipy_spectral', len(classes)) # 'nipy_spectral' is an example of colormap which can give more distinct colors
colors = cmap(np.linspace(0, 1, len(classes)))

for class_id, color in zip(classes, colors):
    idx = (label == class_id)  # get index of all points of this class
    # show bigger tsne points
    scatter_plot = plt.scatter(pca_tsne[idx, 0], pca_tsne[idx, 1], s=150, cmap='tab10', alpha=1.0)
    scatter_plots.append(scatter_plot)
    class_labels.append(str(class_id))

# show bigger legend with class labels

legend = plt.legend(scatter_plots, class_labels, loc='lower center',
                    bbox_to_anchor=(0.5, 1.05), shadow=False, scatterpoints=1, ncol=5, fontsize=24)
plt.text(0.5, -0.1, "PCA", size=36, ha="center", transform=plt.gca().transAxes)


plt.subplot(1, 2, 2)
plt.gca().set_axis_off()
classes = list(set(label))
scatter_plots = []  # list to hold scatter plot for each class
class_labels = []  # list to hold class labels
cmap = plt.cm.get_cmap('nipy_spectral', len(classes)) # 'nipy_spectral' is an example of colormap which can give more distinct colors
colors = cmap(np.linspace(0, 1, len(classes)))

for class_id, color in zip(classes, colors):
    idx = (label == class_id)  # get index of all points of this class
    # show bigger tsne points
    scatter_plot = plt.scatter(cca_tsne[idx, 0], cca_tsne[idx, 1], s=150, cmap='tab10', alpha=1.0)
    scatter_plots.append(scatter_plot)
    class_labels.append(str(class_id))

# show bigger legend with class labels

legend = plt.legend(scatter_plots, class_labels, loc='lower center',
                    bbox_to_anchor=(0.5, 1.05), shadow=False, scatterpoints=1, ncol=5, fontsize=24)
plt.text(0.5, -0.1, "CCA", size=36, ha="center", transform=plt.gca().transAxes)

# save tight
plt.savefig("./Figures/NoisyMNIST-PCA-CCA-TSNE.pdf", bbox_inches='tight')

plt.show()