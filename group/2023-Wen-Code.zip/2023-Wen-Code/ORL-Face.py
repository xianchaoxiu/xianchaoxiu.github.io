import os
import cv2
import numpy as np
import pywt
import matplotlib.pyplot as plt
from skimage.feature import canny
import torch
# 指定图像目录
image_dir = './ORL-Face'

# 初始化列表来存储各种特征和标签
gray_images = []
symlets_images = []
haar_images = []
daubechies_images = []
coiflets_images = []
labels = []
Render = False
# 遍历图像目录的每个子目录
for subdir in os.listdir(image_dir):
    # 获取子目录的绝对路径
    subdir_path = os.path.join(image_dir, subdir)

    # 获取目录中所有的.pgm文件
    pgm_files = [filename for filename in os.listdir(subdir_path) if filename.endswith('.pgm')]

    # 根据样本顺序对文件名进行排序
    sorted_files = sorted(pgm_files, key=lambda filename: int(filename.replace('.pgm', '')))

    # 遍历排序后的每个文件
    for filename in sorted_files:
        # 读取图像
        img = cv2.imread(os.path.join(subdir_path, filename), cv2.IMREAD_GRAYSCALE)
        #img = cv2.resize(img, (64, 64), interpolation=cv2.INTER_LINEAR)

        # 提取Haar小波特征
        coeffs = pywt.dwt2(img, 'haar')
        haar = coeffs[0]
        coeffs = pywt.dwt2(img, 'haar')
        haar = coeffs[0]

        coeffs = pywt.dwt2(img, 'db2')
        daubechies = coeffs[0]
        coeffs = pywt.dwt2(img, 'db2')
        daubechies = coeffs[0]

        coeffs = pywt.dwt2(img, 'coif1')
        coiflets = coeffs[0]
        coeffs = pywt.dwt2(img, 'coif1')
        coiflets = coeffs[0]

        coeffs = pywt.dwt2(img, 'sym2')
        symlets = coeffs[0]
        coeffs = pywt.dwt2(img, 'sym2')
        symlets = coeffs[0]

        # resize to (32, 32) use cv2
        # haar = cv2.resize(haar, (32, 32), interpolation=cv2.INTER_LINEAR)
        # daubechies = cv2.resize(daubechies, (32, 32), interpolation=cv2.INTER_LINEAR)
        # coiflets = cv2.resize(coiflets, (32, 32), interpolation=cv2.INTER_LINEAR)
        # symlets = cv2.resize(symlets, (32, 32), interpolation=cv2.INTER_LINEAR)

        # 将图像和特征添加到列表
        gray_images.append(torch.from_numpy(img / 255.0).unsqueeze(0))

        # direct normalization
        haar_images.append(torch.from_numpy(haar / 255.0).unsqueeze(0))
        daubechies_images.append(torch.from_numpy(daubechies / 255.0).unsqueeze(0))
        coiflets_images.append(torch.from_numpy(coiflets / 255.0).unsqueeze(0))
        symlets_images.append(torch.from_numpy(symlets / 255.0).unsqueeze(0))

        # 最大-最小归一化
        # haar_images.append(torch.from_numpy((haar - haar.min()) / (haar.max() - haar.min())).unsqueeze(0))
        # daubechies_images.append(
        #     torch.from_numpy((daubechies - daubechies.min()) / (daubechies.max() - daubechies.min())).unsqueeze(0))
        # coiflets_images.append(
        #     torch.from_numpy((coiflets - coiflets.min()) / (coiflets.max() - coiflets.min())).unsqueeze(0))
        # symlets_images.append(
        #     torch.from_numpy((symlets - symlets.min()) / (symlets.max() - symlets.min())).unsqueeze(0))


        # 从目录名中提取标签（类别编号）
        label = int(subdir)
        # 保存标签数据
        labels.append(label)

        if Render == False:
            fig, axs = plt.subplots(1, 5, figsize=(12, 6))

            for ax in axs:
                ax.axis('off')

            axs[0].imshow(img, cmap='gray')
            axs[0].set_title(f'Label {label}')

            axs[1].imshow(symlets, cmap='gray')
            axs[1].set_title('Symlets')

            axs[2].imshow(haar, cmap='gray')
            axs[2].set_title('Haar')

            axs[3].imshow(coiflets, cmap='gray')
            axs[3].set_title('Coiflets')

            axs[4].imshow(daubechies, cmap='gray')
            axs[4].set_title('Daubechies')
            # 显示画布
            # save to .pdf
            plt.savefig('./DataFiles/ORL-Face.pdf', bbox_inches='tight')
            plt.show()
            Render = True

# convert list to tensor
gray_images = torch.stack(gray_images, dim=0)
symlets_images = torch.stack(symlets_images, dim=0)
haar_images = torch.stack(haar_images, dim=0)
daubechies_images = torch.stack(daubechies_images, dim=0)
coiflets_images = torch.stack(coiflets_images, dim=0)
labels = torch.tensor(labels)

# shuffle data
indices = torch.randperm(len(gray_images))
gray_images = gray_images[indices]
symlets_images = symlets_images[indices]
haar_images = haar_images[indices]
daubechies_images = daubechies_images[indices]
coiflets_images = coiflets_images[indices]
labels = labels[indices]

# save .pt files
torch.save(gray_images, './DataFiles/ORL-Face-Gray.pt')
torch.save(symlets_images, './DataFiles/ORL-Face-Symlets.pt')
torch.save(haar_images, './DataFiles/ORL-Face-Haar.pt')
torch.save(daubechies_images, './DataFiles/ORL-Face-Daubechies.pt')
torch.save(coiflets_images, './DataFiles/ORL-Face-Coiflets.pt')
torch.save(labels, './DataFiles/ORL-Face-Label.pt')

# save .npy files
# np.save('./DataFiles/ORL-Face-Gray.npy', gray_images.numpy())
# np.save('./DataFiles/ORL-Face-Canny.npy', canny_images.numpy())
# np.save('./DataFiles/ORL-Face-Haar.npy', haar_images.numpy())
# np.save('./DataFiles/ORL-Face-Daubechies.npy', daubechies_images.numpy())
# np.save('./DataFiles/ORL-Face-Coiflets.npy', coiflets_images.numpy())
# np.save('./DataFiles/ORL-Face-Label.npy', labels.numpy())

print("Done!\n")