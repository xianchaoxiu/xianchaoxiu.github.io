from torchvision.datasets import FER2013
from torchvision.transforms import Resize, ToTensor
import torchvision.transforms as transforms

# get FER2013 dataset and transform to 32x32

# Define the transformation
transform = transforms.Compose([
    Resize((32, 32)),
    ToTensor()
])

# Load and preprocess datasets
train_dataset = FER2013(root='./data', split='train', transform=transform)
test_dataset = FER2013(root='./data', split='test', transform=transform)

# Split pictures and label
pictures_train = train_dataset.data
labels_train = train_dataset.targets

pictures_test = test_dataset.data
labels_test = test_dataset.targets

exit(0)
