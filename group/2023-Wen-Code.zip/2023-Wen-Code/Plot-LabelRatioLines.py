import matplotlib.pyplot as plt
import numpy as np
import csv
from matplotlib import font_manager
# read NoisyMNIST-LatentDims.csv
my_font = font_manager.FontProperties(fname='simsun.ttc', size=12)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['axes.unicode_minus'] = False
def read_csv(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        data = list(reader)
    return data

data = read_csv('./ThreeDigitViews-LabelRatio-TCCA.csv')
x = []
y_name_list = []
y_list = []
# First row is 'Latent Dims,10,20,30,40,50,60,70,80,90,100'
for row in data:
    name = row[0]
    all_data = row[1:]
    if name == 'Ratio':
        x = np.array(all_data).astype(int)
    else:
        y_list.append(np.array(all_data).astype(float))
        y_name_list.append(name)

# plot lines
plt.xlabel("有效标签比例（%）", fontproperties=my_font)  # 横坐标名字
plt.ylabel("准确度", fontproperties=my_font)  # 纵坐标名字
cmap = plt.get_cmap('tab20')
for i in range(len(y_list)):
    # plot with random marker and color
    color = cmap(i / len(y_list))
    marker = np.random.choice(['o', 'v', '^', '<', '>', 's', 'p', '*', 'h', 'H', 'D', 'd', 'P', 'X'])
    plt.plot(x, y_list[i], label=y_name_list[i], color=color, marker=marker)

# make legend outside the plot
plt.legend(loc='lower left', bbox_to_anchor=(1, 0.0))
plt.savefig('./Figures/ThreeDigitViews-LabelRatio-Lines.png', dpi=300, bbox_inches='tight')
#save to .pdf
# plt.savefig('./Figures/NoisyMNIST-LatentDims-Lines.pdf', dpi=300, bbox_inches='tight')
plt.show()