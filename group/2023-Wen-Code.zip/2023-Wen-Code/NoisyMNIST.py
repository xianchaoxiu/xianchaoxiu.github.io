import matplotlib.pyplot as plt
import numpy as np
import torchvision
from torchvision import datasets, transforms
import torch

# 加载 MNIST 和 FashionMNIST 数据集
mnist_train = datasets.MNIST(root='./data', train=True, download=True, transform=transforms.ToTensor())
mnist_test = datasets.MNIST(root='./data', train=False, download=True, transform=transforms.ToTensor())

def add_normal_noise(data):
    # use uniform noise
    noise = torch.rand(data.shape)

    # noisy_data = torch.nn.functional.max_pool2d(data, 3, 1, 1)
    noisy_data = data + noise
    noisy_data = torch.clamp(noisy_data, 0., 1.)  # 保证数据在正确的范围内
    return noisy_data

def add_noise_to_dataset(dataset, noise_func, dataset_name):
    original_images = []
    noisy_images = []
    labels = []
    Render = False
    transform_a = torchvision.transforms.RandomRotation((-45, 45))
    transform_b = torchvision.transforms.RandomRotation((-45, 45))

    idx = 0
    for img, label in dataset:
        # random rotate img and noisy_image in range (-45, 45) degree
        img = transform_a(img)
        # random select another img with same label in dataset use random choice
        idx = np.random.choice(np.where(np.array(dataset.targets) == label)[0])

        noisy_img = transform_b(dataset[idx][0])

        noisy_img = noise_func(noisy_img)

        original_images.append(img)
        noisy_images.append(noisy_img)
        labels.append(label)

        if not Render:
            fig, axes = plt.subplots(1, 2, figsize=(10, 5))
            axes[0].imshow(img.squeeze().numpy(), cmap='gray')
            axes[0].set_title('Original Image')
            axes[1].imshow(noisy_img.squeeze().numpy(), cmap='gray')
            axes[1].set_title('Image with Noise')
            plt.show()
            Render = True

    return original_images, noisy_images, labels

original_mnist_train, noisy_mnist_train, labels_mnist_train = add_noise_to_dataset(mnist_train, add_normal_noise, "MNIST_train")
original_mnist_test, noisy_mnist_test, labels_mnist_test = add_noise_to_dataset(mnist_test, add_normal_noise, "MNIST_test")

# split train dataset to train and val
train_size = int(0.8 * len(original_mnist_train))
original_mnist_val = original_mnist_train[train_size:]
noisy_mnist_val = noisy_mnist_train[train_size:]
labels_mnist_val = labels_mnist_train[train_size:]

original_mnist_train = original_mnist_train[:train_size]
noisy_mnist_train = noisy_mnist_train[:train_size]
labels_mnist_train = labels_mnist_train[:train_size]

# convert list to tensor
original_mnist_train = torch.stack(original_mnist_train)
noisy_mnist_train = torch.stack(noisy_mnist_train)
labels_mnist_train = torch.tensor(labels_mnist_train)

original_mnist_val = torch.stack(original_mnist_val)
noisy_mnist_val = torch.stack(noisy_mnist_val)
labels_mnist_val = torch.tensor(labels_mnist_val)

original_mnist_test = torch.stack(original_mnist_test)
noisy_mnist_test = torch.stack(noisy_mnist_test)
labels_mnist_test = torch.tensor(labels_mnist_test)

# save data

torch.save(original_mnist_train, './DataFiles/Noisy-MNIST-Original-Train.pt')
torch.save(noisy_mnist_train, './DataFiles/Noisy-MNIST-Noise-Train.pt')
torch.save(labels_mnist_train, './DataFiles/Noisy-MNIST-Label-Train.pt')

torch.save(original_mnist_val, './DataFiles/Noisy-MNIST-Original-Val.pt')
torch.save(noisy_mnist_val, './DataFiles/Noisy-MNIST-Noise-Val.pt')
torch.save(labels_mnist_val, './DataFiles/Noisy-MNIST-Label-Val.pt')

torch.save(original_mnist_test, './DataFiles/Noisy-MNIST-Original-Test.pt')
torch.save(noisy_mnist_test, './DataFiles/Noisy-MNIST-Noise-Test.pt')
torch.save(labels_mnist_test, './DataFiles/Noisy-MNIST-Label-Test.pt')

# make some train labels to be -1, from ratio 0.05 to 0.5 with step 0.05
for ratio in np.arange(1, 101, 1):
    new_label = labels_mnist_train.clone()
    new_label[:] = -1
    # tensor of random indices
    random_indices = torch.randperm(labels_mnist_train.shape[0])
    # number of labels to keep
    num_labels_to_keep = int(labels_mnist_train.shape[0] * (ratio / 100))
    print(f"{num_labels_to_keep} labels/ {labels_mnist_train.size(0)} to keep:")
    # set labels back to their original values
    new_label[random_indices[:num_labels_to_keep]] = labels_mnist_train[random_indices[:num_labels_to_keep]]
    # save .pt files
    torch.save(new_label, f'./DataFiles/Noisy-MNIST-Label-Train-Ratio-{int(ratio)}.pt')

print("Done!\n")