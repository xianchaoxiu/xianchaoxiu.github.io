import matplotlib.pyplot as plt
from AllDatasetLoader import getORLFaceData, getYaleBData
