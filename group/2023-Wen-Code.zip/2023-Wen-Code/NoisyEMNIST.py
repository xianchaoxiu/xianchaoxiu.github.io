import matplotlib.pyplot as plt
import numpy as np
import torchvision
from torchvision import datasets, transforms
import torch

# 加载 MNIST 和 FashionMNIST 数据集
emnist_balanced_train = datasets.EMNIST(root='./data', split='letters', train=True, download=True, transform=transforms.ToTensor())
emnist_balanced_test = datasets.EMNIST(root='./data', split='letters', train=False, download=True, transform=transforms.ToTensor())

# get classes of EMNIST
classes = emnist_balanced_train.classes

def add_normal_noise(data):
    # use uniform noise
    noise = torch.rand(data.shape)

    # noisy_data = torch.nn.functional.max_pool2d(data, 3, 1, 1)
    noisy_data = data + noise
    noisy_data = torch.clamp(noisy_data, 0., 1.)  # 保证数据在正确的范围内
    return noisy_data

def add_noise_to_dataset(dataset, noise_func):
    original_images = []
    noisy_images = []
    labels = []
    Render = False
    transform_a = torchvision.transforms.RandomRotation((-45, 45))
    transform_b = torchvision.transforms.RandomRotation((-45, 45))
    for img, label in dataset:
        # random rotate img and noisy_image in range (-45, 45) degree
        img = transform_a(img)
        # random select another img with same label in dataset use random choice
        idx = np.random.choice(np.where(np.array(dataset.targets) == label)[0])

        noisy_img = transform_b(dataset[idx][0])

        noisy_img = noise_func(noisy_img)

        original_images.append(img)
        noisy_images.append(noisy_img)
        labels.append(label)
        if not Render:
            fig, axes = plt.subplots(1, 2, figsize=(10, 5))
            axes[0].imshow(img.squeeze().numpy(), cmap='gray')
            axes[0].set_title('Original Image')
            axes[1].imshow(noisy_img.squeeze().numpy(), cmap='gray')
            axes[1].set_title('Image with Noise')
            plt.show()
            Render = True

    return original_images, noisy_images, labels

original_emnist_balanced_train, noisy_emnist_balanced_train, labels_emnist_balanced_train = add_noise_to_dataset(emnist_balanced_train, add_normal_noise)
original_emnist_balanced_test, noisy_emnist_balanced_test, labels_emnist_balanced_test = add_noise_to_dataset(emnist_balanced_test, add_normal_noise)

# convert list to tensor

original_emnist_balanced_train = torch.stack(original_emnist_balanced_train)
noisy_emnist_balanced_train = torch.stack(noisy_emnist_balanced_train)
labels_emnist_balanced_train = torch.tensor(labels_emnist_balanced_train)

original_emnist_balanced_test = torch.stack(original_emnist_balanced_test)
noisy_emnist_balanced_test = torch.stack(noisy_emnist_balanced_test)
labels_emnist_balanced_test = torch.tensor(labels_emnist_balanced_test)

# save data
category = 'Letters'
torch.save(original_emnist_balanced_train, f'./DataFiles/Noisy-EMNIST-{category}-Original-Train.pt')
torch.save(noisy_emnist_balanced_train, f'./DataFiles/Noisy-EMNIST-{category}-Noise-Train.pt')
torch.save(labels_emnist_balanced_train, f'./DataFiles/Noisy-EMNIST-{category}-Label-Train.pt')

torch.save(original_emnist_balanced_test, f'./DataFiles/Noisy-EMNIST-{category}-Original-Test.pt')
torch.save(noisy_emnist_balanced_test, f'./DataFiles/Noisy-EMNIST-{category}-Noise-Test.pt')
torch.save(labels_emnist_balanced_test, f'./DataFiles/Noisy-EMNIST-{category}-Label-Test.pt')

print("Done!\n")