import os
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import matplotlib.pyplot as plt


from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

from sklearn import svm
from sklearn.metrics import accuracy_score
import gzip


class CCA:
    def __init__(self, n_components=1, r1=1e-4, r2=1e-4):
        self.n_components = n_components
        self.r1 = r1
        self.r2 = r2
        self.w = [None, None]
        self.m = [None, None]

    def fit(self, X1, X2):
        # N: number of samples
        # f1: number of features of X1
        # f2: number of features of X2
        N = X1.shape[0]
        f1 = X1.shape[1]
        f2 = X2.shape[1]

        # demeans the data
        # H1bar: X1 - mean(X1),
        # H2bar: X2 - mean(X2)
        # to numpy
        X1 = X1.numpy()
        X2 = X2.numpy()
        self.m[0] = np.mean(X1, axis=0, keepdims=True) # [1, f1]
        self.m[1] = np.mean(X2, axis=0, keepdims=True)
        H1bar = X1 - self.m[0]
        H2bar = X2 - self.m[1]


        SigmaHat12 = (1.0 / (N - 1)) * np.dot(H1bar.T, H2bar)
        SigmaHat11 = (1.0 / (N - 1)) * np.dot(H1bar.T, H1bar) + self.r1 * np.identity(f1)
        SigmaHat22 = (1.0 / (N - 1)) * np.dot(H2bar.T, H2bar) + self.r2 * np.identity(f2)

        # eigen decomposition
        [D1, V1] = np.linalg.eigh(SigmaHat11)
        [D2, V2] = np.linalg.eigh(SigmaHat22)
        SigmaHat11RootInv = np.dot(np.dot(V1, np.diag(D1 ** -0.5)), V1.T)
        SigmaHat22RootInv = np.dot(np.dot(V2, np.diag(D2 ** -0.5)), V2.T)

        Tval = np.dot(np.dot(SigmaHat11RootInv, SigmaHat12), SigmaHat22RootInv)

        [U, D, V] = np.linalg.svd(Tval)
        V = V.T
        self.w[0] = np.dot(SigmaHat11RootInv, U[:, 0:self.n_components])
        self.w[1] = np.dot(SigmaHat22RootInv, V[:, 0:self.n_components])
        D = D[0:self.n_components]

    def _get_result(self, x, idx):
        result = x - self.m[idx].reshape([1, -1]).repeat(len(x), axis=0)
        result = np.dot(result, self.w[idx])
        return result

    def test(self, X1, X2):
        return self._get_result(X1, 0), self._get_result(X2, 1)


from AllDatasetLoader import getNoisyEMNISTData, getNoisyMNISTData, \
    getNoisyFashionMNISTData, getORLFaceData, getYaleBData, \
    getCOIL20Data, randomDropSamplesTo
import torch
import csv

from sklearn.neighbors import KNeighborsClassifier
# load data
# Note: y1 == y2, two views are from the same number.

knn_test_acc_list = []
svm_test_acc_list = []

latent_dim = 20
model_name = "CCA"
dataset_name = "NoisyMNIST"
train_set, val_set, test_set, view_1_shape, view_2_shape = getNoisyMNISTData()

for i in range(9):
    model = CCA(n_components=latent_dim)
    model.fit(train_set.view_1, train_set.view_2)

    Z1_train, Z2_train = model.test(train_set.view_1, train_set.view_2)
    Z1_valid, Z2_valid = model.test(val_set.view_1, val_set.view_2)
    Z1_test, Z2_test = model.test(test_set.view_1, test_set.view_2)

    Z_train = (Z1_train + Z2_train) / 2
    Z_valid = (Z1_valid + Z2_valid) / 2
    Z_test = (Z1_test + Z2_test) / 2

    # KNN classify
    knn = KNeighborsClassifier(n_neighbors=1)
    knn.fit(Z_train, train_set.label)

    knn_train_acc = accuracy_score(train_set.label, knn.predict(Z_train))
    knn_valid_acc = accuracy_score(val_set.label, knn.predict(Z_valid))
    knn_test_acc = accuracy_score(test_set.label, knn.predict(Z_test))

    # print(f"dataset:{dataset_name}, latent_dim:{latent_dim}")
    # print(f"view_1:{view_1}, view_2:{view_2}")
    # print("cca knn: train_acc:{}, valid_acc:{}, test_acc:{}".format(knn_train_acc, knn_valid_acc, knn_test_acc))
    knn_test_acc_list.append(knn_test_acc)
    # SVM classify
    clf = svm.LinearSVC(C=0.01, dual=False)
    clf.fit(Z_train, train_set.label)

    svm_train_acc = accuracy_score(train_set.label, clf.predict(Z_train))
    svm_valid_acc = accuracy_score(val_set.label, clf.predict(Z_valid))
    svm_test_acc = accuracy_score(test_set.label, clf.predict(Z_test))
    #
    # print("cca svm: train_acc:{}, valid_acc:{}, test_acc:{}".format(svm_train_acc, svm_valid_acc, svm_test_acc))
    svm_test_acc_list.append(svm_test_acc)

    print("progress: {}/9".format(i+1))
    latent_dim += 10

# write to csv files, first row is latent dims, second row is test acc

with open(f"result/{dataset_name}_{model_name}_various_latent_dims.csv", "w") as f:
    writer = csv.writer(f)
    # save dataset name and latent dim with comment
    writer.writerow(["dataset_name", dataset_name])
    writer.writerow(["model", model_name])

    # save original results each row
    writer.writerow(["latent_dim"] + [20, 30, 40, 50, 60, 70, 80, 90, 100])
    writer.writerow(["knn"] + knn_test_acc_list)
    writer.writerow(["svm"] + svm_test_acc_list)





