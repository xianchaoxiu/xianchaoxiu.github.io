import os
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import torch
import cv2
# 定义类别的对应关系
category_mapping = {'1': 'Apple', '2': 'Car', '3': 'Cow', '4': 'Cup',
                    '5': 'Dog', '6': 'Horse', '7': 'Pear', '8': 'Tomato'}

# 指定图像目录
image_dir = './ETH-80'
Render = False
# 遍历图像目录的大类别
for large_category_folder in os.listdir(image_dir):
    # 获取大类别名称
    large_category = category_mapping[large_category_folder]

    # 初始化列表来存储RGB分量和标签
    r_images = []
    g_images = []
    b_images = []
    labels = []

    # 遍历大类别目录的小类别
    for small_category_folder in os.listdir(os.path.join(image_dir, large_category_folder)):
        # 只处理小类别文件夹，忽略如apple.txt的文件
        if os.path.isdir(os.path.join(image_dir, large_category_folder, small_category_folder)):
            # 获取小类别目录的绝对路径
            small_category_path = os.path.join(image_dir, large_category_folder, small_category_folder)

            # 获取目录中所有的.png文件
            png_files = [filename for filename in os.listdir(small_category_path) if filename.endswith('.png')]

            # 根据样本顺序对文件名进行排序
            sorted_files = sorted(png_files, key=lambda filename: (
            int(filename.split('-')[1]), int(filename.split('-')[2].replace('.png', ''))))

            # 遍历排序后的每个文件
            for filename in sorted_files:
                # 读取图像
                img = Image.open(os.path.join(small_category_path, filename))
                # 将图像转换为numpy数组
                img_array = np.array(img)

                # use cv2 to resize img to (3, 64, 64)
                img_array = cv2.resize(img_array, (32, 32), interpolation=cv2.INTER_LINEAR)

                r, g, b = img_array[:, :, 0], img_array[:, :, 1], img_array[:, :, 2]
                r_images.append(torch.from_numpy(r / 255.0).unsqueeze(0))
                g_images.append(torch.from_numpy(g / 255.0).unsqueeze(0))
                b_images.append(torch.from_numpy(b / 255.0).unsqueeze(0))
                # 从文件名中提取标签（类别编号）
                # use small_category as label
                label = int(small_category_folder)
                # 保存标签数据
                labels.append(label)

                if Render == False:
                    fig, axs = plt.subplots(1, 4, figsize=(12, 6))

                    for ax in axs:
                        ax.axis('off')
                    # 在左边的子图中渲染原始图像
                    axs[0].imshow(img_array)
                    axs[0].set_title(f'Label {label}')

                    # 在右边的子图中渲染边缘检测后的图像
                    axs[1].imshow(r)
                    axs[1].set_title('R')

                    # 在左边的子图中渲染原始图像
                    axs[2].imshow(g)
                    axs[2].set_title('G')

                    # 在右边的子图中渲染边缘检测后的图像
                    axs[3].imshow(b)
                    axs[3].set_title('B')
                    # 显示画布
                    plt.savefig('./DataFiles/ETH-80.pdf', bbox_inches='tight')
                    plt.show()

                    Render = True

    # convert lists to tensors
    r_images = torch.stack(r_images, dim=0)
    g_images = torch.stack(g_images, dim=0)
    b_images = torch.stack(b_images, dim=0)
    labels = torch.tensor(labels)

    # shuffle data
    indices = torch.randperm(r_images.shape[0])
    r_images = r_images[indices]
    g_images = g_images[indices]
    b_images = b_images[indices]
    labels = labels[indices]

    # save .npy files
    # np.save(f'./DataFiles/ETH-80-{large_category}-R.npy', r_images.numpy())
    # np.save(f'./DataFiles/ETH-80-{large_category}-G.npy', g_images.numpy())
    # np.save(f'./DataFiles/ETH-80-{large_category}-B.npy', b_images.numpy())
    # np.save(f'./DataFiles/ETH-80-{large_category}-Label.npy', labels.numpy())

    # save .pt files
    torch.save(r_images, f'./DataFiles/ETH-80-{large_category}-R.pt')
    torch.save(g_images, f'./DataFiles/ETH-80-{large_category}-G.pt')
    torch.save(b_images, f'./DataFiles/ETH-80-{large_category}-B.pt')
    torch.save(labels, f'./DataFiles/ETH-80-{large_category}-Label.pt')

    print(f'Processed {large_category} category\n')

print('Done!\n')