import torch
from mvlearn.datasets import load_UCImultifeature

data, labels = load_UCImultifeature()

for i in range(len(data)):
    # use max-min normalization to normalize each view of data
    data[i] = (data[i] - data[i].min()) / (data[i].max() - data[i].min())
    # convert data to tensor
    data[i] = torch.tensor(data[i], dtype=torch.float32)
    # save data to file
    torch.save(data[i], f'./DataFiles/UCI-MFD-View-{i+1}.pt')

# convert labels to tensor
labels = torch.tensor(labels, dtype=torch.int64)
torch.save(labels, './DataFiles/UCI-MFD-Labels.pt')
