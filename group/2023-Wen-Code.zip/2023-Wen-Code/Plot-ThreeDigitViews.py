from AllDatasetLoader import getThreeDigitViewsData
import matplotlib.pyplot as plt
import numpy as np

train_set, _, _, _, _, _ = getThreeDigitViewsData()
view_1 = train_set.view_1[:10].reshape(-1, 28, 28)
view_2 = train_set.view_2[:10].reshape(-1, 28, 28)
view_3 = train_set.view_3[:10].reshape(-1, 28, 28)
label = train_set.label[:10]

# show first 10 images
fig, axes = plt.subplots(3, 10, figsize=(10, 3))
for i in range(10):
    axes[0, i].imshow(view_1[i], cmap='gray')
    # axes[0, i].set_title(f"{int(label[i])}")
    axes[0, i].axis('off')

    axes[1, i].imshow(view_2[i], cmap='gray')
    axes[1, i].axis('off')

    axes[2, i].imshow(view_3[i], cmap='gray')
    axes[2, i].axis('off')

# save .pdf file
plt.savefig('ThreeDigitViews.pdf', bbox_inches='tight')
plt.show()
