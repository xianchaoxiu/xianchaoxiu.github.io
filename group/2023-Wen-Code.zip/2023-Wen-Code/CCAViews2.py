import os
os.environ["OMP_NUM_THREADS"] = "8"

import numpy as np
import matplotlib.pyplot as plt


from sklearn.manifold import TSNE
from sklearn.decomposition import PCA

from sklearn import svm
from sklearn.metrics import accuracy_score
import gzip


class CCA:
    def __init__(self, n_components=1, r1=1e-4, r2=1e-4):
        self.n_components = n_components
        self.r1 = r1
        self.r2 = r2
        self.w = [None, None]
        self.m = [None, None]

    def fit(self, X1, X2):
        # N: number of samples
        # f1: number of features of X1
        # f2: number of features of X2
        N = X1.shape[0]
        f1 = X1.shape[1]
        f2 = X2.shape[1]

        # demeans the data
        # H1bar: X1 - mean(X1),
        # H2bar: X2 - mean(X2)
        # to numpy
        X1 = X1.numpy()
        X2 = X2.numpy()
        self.m[0] = np.mean(X1, axis=0, keepdims=True) # [1, f1]
        self.m[1] = np.mean(X2, axis=0, keepdims=True)
        H1bar = X1 - self.m[0]
        H2bar = X2 - self.m[1]


        SigmaHat12 = (1.0 / (N - 1)) * np.dot(H1bar.T, H2bar)
        SigmaHat11 = (1.0 / (N - 1)) * np.dot(H1bar.T, H1bar) + self.r1 * np.identity(f1)
        SigmaHat22 = (1.0 / (N - 1)) * np.dot(H2bar.T, H2bar) + self.r2 * np.identity(f2)

        # eigen decomposition
        [D1, V1] = np.linalg.eigh(SigmaHat11)
        [D2, V2] = np.linalg.eigh(SigmaHat22)
        SigmaHat11RootInv = np.dot(np.dot(V1, np.diag(D1 ** -0.5)), V1.T)
        SigmaHat22RootInv = np.dot(np.dot(V2, np.diag(D2 ** -0.5)), V2.T)

        Tval = np.dot(np.dot(SigmaHat11RootInv, SigmaHat12), SigmaHat22RootInv)

        [U, D, V] = np.linalg.svd(Tval)
        V = V.T
        self.w[0] = np.dot(SigmaHat11RootInv, U[:, 0:self.n_components])
        self.w[1] = np.dot(SigmaHat22RootInv, V[:, 0:self.n_components])
        D = D[0:self.n_components]

    def _get_result(self, x, idx):
        result = x - self.m[idx].reshape([1, -1]).repeat(len(x), axis=0)
        result = np.dot(result, self.w[idx])
        return result

    def test(self, X1, X2):
        return self._get_result(X1, 0), self._get_result(X2, 1)


from AllDatasetLoader import getNoisyEMNISTData, getNoisyMNISTData, \
    getNoisyFashionMNISTData, getORLFaceData, getYaleBData, \
    getCOIL20Data, randomDropSamplesTo
import torch
# load data
# Note: y1 == y2, two views are from the same number.
latent_dim = 80
render_tsne = True
model_name = "CCA"
dataset_name = "COIL-20"
view_1 = "gray"
view_2 = "symlets"
pca_dim = 150
train_set, val_set, test_set, view_1_shape, view_2_shape = getCOIL20Data(view_1=view_1, view_2=view_2)

# X1_train, X2_train, X1_valid, X2_valid, X1_test, X2_test, \
#     y1_train, y2_train, y1_valid, y2_valid, y1_test, y2_test = \
#     getZooNoisyMNIST(50000, 10000, 1024, 1024)


# other noisy mnist data
# split train_set to X1_train, X2_train and y1_train, y2_train
# train_set.view_1 = torch.from_numpy(X1_train)
# train_set.view_2 = torch.from_numpy(X2_train)
# train_set.label = torch.from_numpy(y1_train)
# train_set.train_label = torch.from_numpy(y1_train)
# train_set.dataset_length = len(y1_train)
#
#
# # split valid_set to X1_valid, X2_valid and y1_valid, y2_valid
# val_set.view_1 = torch.from_numpy(X1_valid)
# val_set.view_2 = torch.from_numpy(X2_valid)
# val_set.label = torch.from_numpy(y1_valid)
# val_set.train_label = torch.from_numpy(y1_valid)
# val_set.dataset_length = len(y1_valid)
#
#
# # split test_set to X1_test, X2_test and y1_test, y2_test
# test_set.view_1 = torch.from_numpy(X1_test)
# test_set.view_2 = torch.from_numpy(X2_test)
# test_set.label = torch.from_numpy(y1_test)
# test_set.train_label = torch.from_numpy(y1_test)
# test_set.dataset_length = len(y1_test)
# CCA feature extraction

# use pca to reduce dimension to 100
pca = PCA(n_components=pca_dim)
pca.fit(train_set.view_1)
train_set.view_1 = pca.transform(train_set.view_1)
val_set.view_1 = pca.transform(val_set.view_1)
test_set.view_1 = pca.transform(test_set.view_1)

pca = PCA(n_components=pca_dim)
pca.fit(train_set.view_2)
train_set.view_2 = pca.transform(train_set.view_2)
val_set.view_2 = pca.transform(val_set.view_2)
test_set.view_2 = pca.transform(test_set.view_2)

# convert to tensor
train_set.view_1 = torch.from_numpy(train_set.view_1)
train_set.view_2 = torch.from_numpy(train_set.view_2)
val_set.view_1 = torch.from_numpy(val_set.view_1)
val_set.view_2 = torch.from_numpy(val_set.view_2)
test_set.view_1 = torch.from_numpy(test_set.view_1)
test_set.view_2 = torch.from_numpy(test_set.view_2)


model = CCA(n_components=latent_dim)
model.fit(train_set.view_1, train_set.view_2)

Z1_train, Z2_train = model.test(train_set.view_1, train_set.view_2)
Z1_valid, Z2_valid = model.test(val_set.view_1, val_set.view_2)
Z1_test, Z2_test = model.test(test_set.view_1, test_set.view_2)

Z_train = (Z1_train + Z2_train) / 2
Z_valid = (Z1_valid + Z2_valid) / 2
Z_test = (Z1_test + Z2_test) / 2

# KNN classify
from sklearn.neighbors import KNeighborsClassifier
knn = KNeighborsClassifier(n_neighbors=1)
knn.fit(Z_train, train_set.label)

knn_train_acc = accuracy_score(train_set.label, knn.predict(Z_train))
knn_valid_acc = accuracy_score(val_set.label, knn.predict(Z_valid))
knn_test_acc = accuracy_score(test_set.label, knn.predict(Z_test))

print(f"dataset:{dataset_name}, latent_dim:{latent_dim}")
print(f"view_1:{view_1}, view_2:{view_2}")
print("cca knn: train_acc:{}, valid_acc:{}, test_acc:{}".format(knn_train_acc, knn_valid_acc, knn_test_acc))

# SVM classify
clf = svm.LinearSVC(C=0.01, dual=False)
clf.fit(Z_train, train_set.label)

svm_train_acc = accuracy_score(train_set.label, clf.predict(Z_train))
svm_valid_acc = accuracy_score(val_set.label, clf.predict(Z_valid))
svm_test_acc = accuracy_score(test_set.label, clf.predict(Z_test))

print("cca svm: train_acc:{}, valid_acc:{}, test_acc:{}".format(svm_train_acc, svm_valid_acc, svm_test_acc))

if render_tsne == False:
    exit(0)
tsne = TSNE()
Z_tsne = tsne.fit_transform(Z_test)
# np.save("dcca_tsne_result.npy", Z_tsne)
# hide axis
fig = plt.figure(figsize=(14, 14))
ax = plt.axes(frameon=False)
plt.setp(ax, xticks=(), yticks=())

# add scatter plots for each class
classes = list(set(test_set.label.numpy()))
scatter_plots = []  # list to hold scatter plot for each class
class_labels = []  # list to hold class labels
cmap = plt.cm.get_cmap('nipy_spectral', len(classes)) # 'nipy_spectral' is an example of colormap which can give more distinct colors
colors = cmap(np.linspace(0, 1, len(classes)))

for class_id, color in zip(classes, colors):
    idx = (test_set.label.numpy() == class_id)  # get index of all points of this class
    # show bigger tsne points
    scatter_plot = plt.scatter(Z_tsne[idx, 0], Z_tsne[idx, 1], s=150, color=color, alpha=1.0)
    scatter_plots.append(scatter_plot)
    class_labels.append(str(class_id))

# show bigger legend with class labels

legend = plt.legend(scatter_plots, class_labels, loc='lower center',
                    bbox_to_anchor=(0.5, 1.05), shadow=False, scatterpoints=1, ncol=10, fontsize=16)
# draw train_acc, valid_acc, test_acc in .4f on the bottom of the figure in big font size
plt.text(0.5, -0.05, f"Unsupervised {model_name}, Latent Dim {latent_dim} \n"
                     f"KNN: train_acc: {knn_train_acc:.4f}, valid_acc: {knn_valid_acc:.4f}, test_acc: {knn_test_acc:.4f} \n"
                     f"SVM: train_acc: {svm_train_acc:.4f}, valid_acc: {svm_valid_acc:.4f}, test_acc: {svm_test_acc:.4f} \n ",
            horizontalalignment='center', verticalalignment='center', transform=ax.transAxes, fontsize=26)

# save figure
# plt.savefig('dcca_tsne_result.pdf', bbox_inches='tight', dpi=300, format='pdf')
plt.show()
np.save(f"./Figures/{dataset_name}-CCA-TSNE.npy", Z_tsne)
np.save(f"./Figures/{dataset_name}-CCA-Label.npy", test_set.label.numpy().astype(int))


# def calc_corr(Z1, Z2):
#     N, F = Z1.shape
#
#     corrs = [np.corrcoef(z1, z2)[0, 1] for z1, z2 in zip(Z1.T, Z2.T)]
#     return corrs
#
# print(np.mean(calc_corr(Z1_valid, Z2_valid)))
# print(np.mean(calc_corr(Z1_test, Z2_test)))

# SVM baseline

