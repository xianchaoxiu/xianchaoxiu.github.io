import os
import numpy as np
from PIL import Image
from skimage import feature
import pywt
import matplotlib.pyplot as plt
import torch
import cv2

# 指定图像目录
image_dir = './coil-20'

# 初始化列表来存储图像的灰度值、标签和各种小波变换后的结果
gray_images = []
symlets_images = []
haar_transformed_images = []
coiflets_transformed_images = []
daubechies_transformed_images = []
labels = []
Render = False

# 获取目录中所有的.png文件
png_files = [filename for filename in os.listdir(image_dir) if filename.endswith('.png')]

# 根据标签和样本顺序对文件名进行排序
sorted_files = sorted(
    png_files, key=lambda filename: (int(filename.split('__')[0].replace('obj', '')), int(filename.split('__')[1].
                                                                                          replace('.png', ''))))


# 遍历目录中的每个文件
for filename in sorted_files:
    # 检查文件是否为.png图像
    img = Image.open(os.path.join(image_dir, filename)).convert('L')
    # 将图像转换为numpy数组
    img_array = np.array(img)
    # 保存灰度图像数据
    #img_array = img_array / 255.0

    # 从文件名中提取标签（obj编号）
    label = int(filename.split('__')[0].replace('obj', ''))
    # 保存标签数据
    labels.append(label)
    # 进行haar、Coiflets、Daubechies小波变换

    # use cv2 to resize img to (64, 64)
    #img_array = cv2.resize(img_array, (128, 128), interpolation=cv2.INTER_LINEAR)

    haar_coeffs, _ = pywt.dwt2(img_array, 'haar')
    haar_coeffs, _ = pywt.dwt2(img_array, 'haar')
    coif_coeffs, _ = pywt.dwt2(img_array, 'coif1')
    coif_coeffs, _ = pywt.dwt2(img_array, 'coif1')
    db_coeffs, _ = pywt.dwt2(img_array, 'db2')
    db_coeffs, _ = pywt.dwt2(img_array, 'db2')
    sym_coeffs, _ = pywt.dwt2(img_array, 'sym2')
    sym_coeffs, _ = pywt.dwt2(img_array, 'sym2')
    # resize to (64, 64)
    # haar_coeffs = cv2.resize(haar_coeffs, (64, 64), interpolation=cv2.INTER_LINEAR)
    # coif_coeffs = cv2.resize(coif_coeffs, (64, 64), interpolation=cv2.INTER_LINEAR)
    # db_coeffs = cv2.resize(db_coeffs, (64, 64), interpolation=cv2.INTER_LINEAR)
    # sym_coeffs = cv2.resize(sym_coeffs, (64, 64), interpolation=cv2.INTER_LINEAR)

    # 进行Canny边缘检测

    gray_images.append(torch.from_numpy(img_array / 255.0).unsqueeze(0))


    # Direct normalization
    haar_transformed_images.append(torch.from_numpy(haar_coeffs / 255.0).unsqueeze(0))
    coiflets_transformed_images.append(torch.from_numpy(coif_coeffs / 255.0).unsqueeze(0))
    daubechies_transformed_images.append(torch.from_numpy(db_coeffs / 255.0).unsqueeze(0))
    symlets_images.append(torch.from_numpy(sym_coeffs / 255.0).unsqueeze(0))

    # Max-min normalization
    # haar_transformed_images.append(
    #     torch.from_numpy((haar_coeffs - haar_coeffs.min()) / (haar_coeffs.max() - haar_coeffs.min())).unsqueeze(0))
    # coiflets_transformed_images.append(
    #     torch.from_numpy((coif_coeffs - coif_coeffs.min()) / (coif_coeffs.max() - coif_coeffs.min())).unsqueeze(0))
    # daubechies_transformed_images.append(
    #     torch.from_numpy((db_coeffs - db_coeffs.min()) / (db_coeffs.max() - db_coeffs.min())).unsqueeze(0))
    # symlets_images.append(
    #     torch.from_numpy((sym_coeffs - sym_coeffs.min()) / (sym_coeffs.max() - sym_coeffs.min())).unsqueeze(0))


    # 保存边缘检测后的图像数据

    if Render == False:
        # 创建一个包含5个子图的图像
        fig, axs = plt.subplots(1, 5, figsize=(12, 6))
        # hide axis
        for ax in axs:
            ax.axis('off')

        axs[0].imshow(img_array, cmap='gray')
        axs[0].set_title(f'Label {label}')

        axs[1].imshow(sym_coeffs, cmap='gray')
        axs[1].set_title('Symlets')

        axs[2].imshow(haar_coeffs, cmap='gray')
        axs[2].set_title('Haar')

        axs[3].imshow(coif_coeffs, cmap='gray')
        axs[3].set_title('Coiflets')

        axs[4].imshow(db_coeffs, cmap='gray')
        axs[4].set_title('Daubechies')

        plt.savefig('./DataFiles/COIL20.pdf', bbox_inches='tight')
        plt.show()
        Render = True

# 将列表转换为numpy数组
gray_images = torch.stack(gray_images, dim=0)
symlets_images = torch.stack(symlets_images, dim=0)
haar_transformed_images = torch.stack(haar_transformed_images, dim=0)
coiflets_transformed_images = torch.stack(coiflets_transformed_images, dim=0)
daubechies_transformed_images = torch.stack(daubechies_transformed_images, dim=0)
labels = torch.tensor(labels)

# shuffle data
indices = torch.randperm(gray_images.size(0))
gray_images = gray_images[indices]
symlets_images = symlets_images[indices]
haar_transformed_images = haar_transformed_images[indices]
coiflets_transformed_images = coiflets_transformed_images[indices]
daubechies_transformed_images = daubechies_transformed_images[indices]
labels = labels[indices]

# save .npy files
# np.save('./DataFiles/COIL-20-Gray.npy', gray_images.numpy())
# np.save('./DataFiles/COIL-20-Label.npy', labels.numpy())
# np.save('./DataFiles/COIL-20-Haar.npy', haar_transformed_images.numpy())
# np.save('./DataFiles/COIL-20-Coiflets.npy', coiflets_transformed_images.numpy())
# np.save('./DataFiles/COIL-20-Daubechies.npy', daubechies_transformed_images.numpy())
# np.save('./DataFiles/COIL-20-Canny.npy', canny_images.numpy())

# save .pt files
torch.save(gray_images, './DataFiles/COIL-20-Gray.pt')
torch.save(symlets_images, './DataFiles/COIL-20-Symlets.pt')
torch.save(haar_transformed_images, './DataFiles/COIL-20-Haar.pt')
torch.save(coiflets_transformed_images, './DataFiles/COIL-20-Coiflets.pt')
torch.save(daubechies_transformed_images, './DataFiles/COIL-20-Daubechies.pt')
torch.save(labels, './DataFiles/COIL-20-Label.pt')

print("\nDone!\n")