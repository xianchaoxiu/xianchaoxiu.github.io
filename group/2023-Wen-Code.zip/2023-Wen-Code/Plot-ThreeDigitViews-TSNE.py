import numpy as np
import matplotlib.pyplot as plt
# import tsne
from sklearn.manifold import TSNE
# load data
def plot_tsne(tsne_data, label, plot, title, show_legend=True):
    classes = list(set(label))
    scatter_plots = []  # list to hold scatter plot for each class
    class_labels = []  # list to hold class labels
    cmap = plt.colormaps.get_cmap('nipy_spectral')  # 'nipy_spectral' is an example of colormap which can give more distinct colors
    # get more distinct colors
    colors = cmap(np.linspace(0, 1, len(classes)))

    for class_id, color in zip(classes, colors):
        idx = (label == class_id)
        # show bigger tsne points
        scatter_plot = plot.scatter(tsne_data[idx, 0], tsne_data[idx, 1], s=150, color=color, alpha=1.0)
        scatter_plots.append(scatter_plot)
        class_labels.append(str(class_id))

    # make legend under the tsne plot and show bigger and hind border
    if show_legend:
        legend = plot.legend(scatter_plots, class_labels, loc='upper left',
                                bbox_to_anchor=(0.0, 1.4), shadow=False, ncol=10, fontsize=54, markerscale=2.5)
        frame = legend.get_frame()
        frame.set_facecolor('white')

    plot.set_title(title, fontsize=60, y=-0.01)


dataset_name = "ETH-80-All"
# load unsupervised model data

# mcca_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-MCCA3-TSNE.npy")
# mcca_label = np.load(f"./Figures/{dataset_name}-Unsupervised-MCCA3-Label.npy")

dcca_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-DCCA3-TSNE.npy")
dcca_label = np.load(f"./Figures/{dataset_name}-Unsupervised-DCCA3-Label.npy")

dccae_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-DCCAE3-TSNE.npy")
dccae_label = np.load(f"./Figures/{dataset_name}-Unsupervised-DCCAE3-Label.npy")

convcca_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-ConvCCA3-TSNE.npy")
convcca_label = np.load(f"./Figures/{dataset_name}-Unsupervised-ConvCCA3-Label.npy")

rescca_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-ResCCA3-TSNE.npy")
rescca_label = np.load(f"./Figures/{dataset_name}-Unsupervised-ResCCA3-Label.npy")

convccae_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-ConvCCAE3-TSNE.npy")
convccae_label = np.load(f"./Figures/{dataset_name}-Unsupervised-ConvCCAE3-Label.npy")

resccae_tsne = np.load(f"./Figures/{dataset_name}-Unsupervised-ResCCAE3-TSNE.npy")
resccae_label = np.load(f"./Figures/{dataset_name}-Unsupervised-ResCCAE3-Label.npy")

# load supervised data

s_dcca_tsne = np.load(f"./Figures/{dataset_name}-Supervised-DCCA3-TSNE.npy")
s_dcca_label = np.load(f"./Figures/{dataset_name}-Supervised-DCCA3-Label.npy")

s_dccae_tsne = np.load(f"./Figures/{dataset_name}-Supervised-DCCAE3-TSNE.npy")
s_dccae_label = np.load(f"./Figures/{dataset_name}-Supervised-DCCAE3-Label.npy")

s_convcca_tsne = np.load(f"./Figures/{dataset_name}-Supervised-ConvCCA3-TSNE.npy")
s_convcca_label = np.load(f"./Figures/{dataset_name}-Supervised-ConvCCA3-Label.npy")

s_rescca_tsne = np.load(f"./Figures/{dataset_name}-Supervised-ResCCA3-TSNE.npy")
s_rescca_label = np.load(f"./Figures/{dataset_name}-Supervised-ResCCA3-Label.npy")

s_convccae_tsne = np.load(f"./Figures/{dataset_name}-Supervised-ConvCCAE3-TSNE.npy")
s_convccae_label = np.load(f"./Figures/{dataset_name}-Supervised-ConvCCAE3-Label.npy")

s_resccae_tsne = np.load(f"./Figures/{dataset_name}-Supervised-ResCCAE3-TSNE.npy")
s_resccae_label = np.load(f"./Figures/{dataset_name}-Supervised-ResCCAE3-Label.npy")



# plot tsne with bigger points and legend

fig, axs = plt.subplots(nrows=3, ncols=4, figsize=(12 * 6, 12 * 4))  # change to 1 row and 4 columns

# make space between subplot bigger
plt.subplots_adjust(wspace=0.5, hspace=0.5)

# plot tsne and hide axis
plot_tsne(dcca_tsne, dcca_label, axs[0, 0], "DCCA", show_legend=True)
axs[0, 0].axis('off')
axs[0, 0].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_dcca_tsne, s_dcca_label, axs[0, 1], "SDCCA", show_legend=False)
axs[0, 1].axis('off')
axs[0, 1].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(dccae_tsne, dccae_label, axs[0, 2], "DCCAE", show_legend=False)
axs[0, 2].axis('off')
axs[0, 2].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_dccae_tsne, s_dccae_label, axs[0, 3], "SDCCAE", show_legend=False)
axs[0, 3].axis('off')
axs[0, 3].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(convcca_tsne, convcca_label, axs[1, 0], "ConvCCA", show_legend=False)
axs[1, 0].axis('off')
axs[1, 0].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_convcca_tsne, s_convcca_label, axs[1, 1], "SConvCCA", show_legend=False)
axs[1, 1].axis('off')
axs[1, 1].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(rescca_tsne, rescca_label, axs[1, 2], "ResCCA", show_legend=False)
axs[1, 2].axis('off')
axs[1, 2].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_rescca_tsne, s_rescca_label, axs[1, 3], "SResCCA", show_legend=False)
axs[1, 3].axis('off')
axs[1, 3].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(convccae_tsne, convccae_label, axs[2, 0], "ConvCCAE", show_legend=False)
axs[2, 0].axis('off')
axs[2, 0].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_convccae_tsne, s_convccae_label, axs[2, 1], "SConvCCAE", show_legend=False)
axs[2, 1].axis('off')
axs[2, 1].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(resccae_tsne, resccae_label, axs[2, 2], "ResCCAE", show_legend=False)
axs[2, 2].axis('off')
axs[2, 2].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(s_resccae_tsne, s_resccae_label, axs[2, 3], "SResCCAE", show_legend=False)
axs[2, 3].axis('off')
axs[2, 3].title.set_position([.5, -0.1])  # move title to below the plot


# plot supervised tsne and hide axis

# save to svg
#plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.svg", bbox_inches='tight', pad_inches=0)

# save to png more clear
plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.png", bbox_inches='tight', pad_inches=0, dpi=300)
plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.pdf", bbox_inches='tight', pad_inches=0)
plt.show()
