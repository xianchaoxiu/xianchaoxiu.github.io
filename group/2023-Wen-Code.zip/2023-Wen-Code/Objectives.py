import torch

import tensorly as tl
from tensorly.cp_tensor import cp_to_tensor
from tensorly.decomposition import parafac

# numerical stability
r1 = r2 = r = 1e-3
eps = 1e-4

def _mat_pow(mat, pow_, epsilon):
    # Computing matrix to the power of pow (pow can be negative as well)
    [D, V] = torch.linalg.eigh(mat)
    mat_pow = V @ torch.diag((D + epsilon).pow(pow_)) @ V.T
    mat_pow[mat_pow != mat_pow] = epsilon  # For stability
    return mat_pow


def _demean(views):
    return tuple([view - view.mean(dim=0) for view in views])

def CCALoss(H1, H2, outdim_size):

    H1, H2 = H1.t(), H2.t()

    o1 = o2 = H1.size(0)

    m = H1.size(1)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)

    SigmaHat12 = (1.0 / (m - 1)) * torch.matmul(H1bar, H2bar.t())
    SigmaHat11 = (1.0 / (m - 1)) * torch.matmul(H1bar, H1bar.t()) + r1 * torch.eye(o1, device=H1.device)
    SigmaHat22 = (1.0 / (m - 1)) * torch.matmul(H2bar, H2bar.t()) + r2 * torch.eye(o2, device=H1.device)

    # Calculating the root inverse of covariance matrices by using eigen decomposition
    [D1, V1] = torch.linalg.eigh(SigmaHat11)
    [D2, V2] = torch.linalg.eigh(SigmaHat22)

    # Added to increase stability
    posInd1 = torch.gt(D1, eps).nonzero()[:, 0]
    D1 = D1[posInd1]
    V1 = V1[:, posInd1]
    posInd2 = torch.gt(D2, eps).nonzero()[:, 0]
    D2 = D2[posInd2]
    V2 = V2[:, posInd2]

    SigmaHat11RootInv = torch.matmul(torch.matmul(V1, torch.diag(D1 ** -0.5)), V1.t())
    SigmaHat22RootInv = torch.matmul(torch.matmul(V2, torch.diag(D2 ** -0.5)), V2.t())

    Tval = torch.matmul(torch.matmul(SigmaHat11RootInv, SigmaHat12), SigmaHat22RootInv)

    # just the top outdim_size singular values are used
    trace_TT = torch.matmul(Tval.t(), Tval)
    trace_TT = torch.add(trace_TT,
                         (torch.eye(trace_TT.shape[0]) * r1).to(H1.device))  # regularization for more stability
    U, V = torch.linalg.eigh(trace_TT)
    U = torch.where(U > eps, U, (torch.ones(U.shape) * eps).to(H1.device))
    U = U.topk(outdim_size)[0]
    corr = torch.sum(torch.sqrt(U))

    return - corr

def MCCALoss2(H1, H2, outdim_size):
    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar]

    all_views = torch.cat(views, dim=1)
    C = all_views.T @ all_views / (n - 1)

    D = torch.block_diag(
        *[
            (1 - r) * m.T @ m / (n - 1)
            + r * torch.eye(m.shape[1], device=m.device)
            for i, m in enumerate(views)
        ]
    )

    C = C - torch.block_diag(*[view.T @ view / (n - 1) for view in views]) + D

    R = _mat_pow(D, -0.5, eps)

    C_whitened = R @ C @ R.T

    eigvals = torch.linalg.eigvalsh(C_whitened)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def MCCALoss6(H1, H2, H3, H4, H5, H6, outdim_size):
    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)
    H4bar = H4 - H4.mean(dim=1).unsqueeze(dim=1)
    H5bar = H5 - H5.mean(dim=1).unsqueeze(dim=1)
    H6bar = H6 - H6.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar, H4bar, H5bar, H6bar]

    all_views = torch.cat(views, dim=1)
    C = all_views.T @ all_views / (n - 1)

    D = torch.block_diag(
        *[
            1 * m.T @ m / (n - 1)
            + r * torch.eye(m.shape[1], device=m.device)
            for i, m in enumerate(views)
        ]
    )

    C = C - torch.block_diag(*[view.T @ view / (n - 1) for view in views]) + D

    R = _mat_pow(D, -0.5, eps)

    C_whitened = R @ C @ R.T

    eigvals = torch.linalg.eigvalsh(C_whitened)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def GCCALoss6(H1, H2, H3, H4, H5, H6, outdim_size):
    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)
    H4bar = H4 - H4.mean(dim=1).unsqueeze(dim=1)
    H5bar = H5 - H5.mean(dim=1).unsqueeze(dim=1)
    H6bar = H6 - H6.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar, H4bar, H5bar, H6bar]

    eigen_views = [
        view @ _mat_pow(view.T @ view / (n - 1), -1, eps) @ view.T
        for view in views
    ]

    Q = torch.stack(eigen_views, dim=0).sum(dim=0)
    eigvals = torch.linalg.eigvalsh(Q)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def TCCALoss6(H1, H2, H3, H4, H5, H6, outdim_size):
    n = H1.size(0)
    eps = 1e-3
    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)
    H4bar = H4 - H4.mean(dim=1).unsqueeze(dim=1)
    H5bar = H5 - H5.mean(dim=1).unsqueeze(dim=1)
    H6bar = H6 - H6.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar, H4bar, H5bar, H6bar]

    covs = [
        1 * view.T @ view / (n - 1)
        + r * torch.eye(view.size(1), device=view.device)
        for view in views
    ]
    whitened_z = [
        view @ _mat_pow(cov, -0.5, eps) for view, cov in zip(views, covs)
    ]

    for i, el in enumerate(whitened_z):

        if i == 0:
            M = el

        else:
            for _ in range(len(M.size()) - 1):
                el = torch.unsqueeze(el, 1)
            M = torch.unsqueeze(M, -1) @ el
    M = torch.mean(M, 0)
    tl.set_backend("pytorch")
    M_parafac = parafac(
        M.detach(), outdim_size, verbose=False, normalize_factors=True
    )
    M_parafac.weights = 1
    M_hat = cp_to_tensor(M_parafac)

    return torch.linalg.norm(M - M_hat)

def MCCALoss3(H1, H2, H3, outdim_size):

    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar]

    all_views = torch.cat(views, dim=1)
    C = all_views.T @ all_views / (n - 1)

    D = torch.block_diag(
        *[
            (1 - r) * m.T @ m / (n - 1)
            + r * torch.eye(m.shape[1], device=m.device)
            for i, m in enumerate(views)
        ]
    )

    C = C - torch.block_diag(*[view.T @ view / (n - 1) for view in views]) + D

    R = _mat_pow(D, -0.5, eps)

    C_whitened = R @ C @ R.T

    eigvals = torch.linalg.eigvalsh(C_whitened)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def GCCALoss2(H1, H2, outdim_size):

    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar]

    eigen_views = [
        view @ _mat_pow(view.T @ view / (n - 1), -1, eps) @ view.T
        for view in views
    ]

    Q = torch.stack(eigen_views, dim=0).sum(dim=0)
    eigvals = torch.linalg.eigvalsh(Q)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def GCCALoss3(H1, H2, H3, outdim_size):

    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar]

    eigen_views = [
        view @ _mat_pow(view.T @ view / (n - 1), -1, eps) @ view.T
        for view in views
    ]

    Q = torch.stack(eigen_views, dim=0).sum(dim=0)
    eigvals = torch.linalg.eigvalsh(Q)

    idx = torch.argsort(eigvals, descending=True)

    eigvals = eigvals[idx[: outdim_size]]

    eigvals = torch.nn.LeakyReLU()(eigvals[torch.gt(eigvals, 0)] - 1)

    corr = eigvals.sum()

    return - corr

def TCCALoss2(H1, H2, outdim_size):

    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar]

    covs = [
        (1 - r) * view.T @ view / (n - 1)
        + r * torch.eye(view.size(1), device=view.device)
        for view in views
    ]
    whitened_z = [
        view @ _mat_pow(cov, -0.5, eps) for view, cov in zip(views, covs)
    ]

    for i, el in enumerate(whitened_z):

        if i == 0:
            M = el

        else:
            for _ in range(len(M.size()) - 1):
                el = torch.unsqueeze(el, 1)
            M = torch.unsqueeze(M, -1) @ el
    M = torch.mean(M, 0)
    tl.set_backend("pytorch")
    M_parafac = parafac(
        M.detach(), outdim_size, verbose=False, normalize_factors=True
    )
    M_parafac.weights = 1
    M_hat = cp_to_tensor(M_parafac)

    return torch.linalg.norm(M - M_hat)

def TCCALoss3(H1, H2, H3, outdim_size):
    n = H1.size(0)

    H1bar = H1 - H1.mean(dim=1).unsqueeze(dim=1)
    H2bar = H2 - H2.mean(dim=1).unsqueeze(dim=1)
    H3bar = H3 - H3.mean(dim=1).unsqueeze(dim=1)

    views = [H1bar, H2bar, H3bar]

    covs = [
        (1 - r) * view.T @ view / (n - 1)
        + r * torch.eye(view.size(1), device=view.device)
        for view in views
    ]
    whitened_z = [
        view @ _mat_pow(cov, -0.5, eps) for view, cov in zip(views, covs)
    ]

    for i, el in enumerate(whitened_z):

        if i == 0:
            M = el

        else:
            for _ in range(len(M.size()) - 1):
                el = torch.unsqueeze(el, 1)
            M = torch.unsqueeze(M, -1) @ el
    M = torch.mean(M, 0)
    tl.set_backend("pytorch")
    M_parafac = parafac(
        M.detach(), outdim_size, verbose=False, normalize_factors=True
    )
    M_parafac.weights = 1
    M_hat = cp_to_tensor(M_parafac)

    return torch.linalg.norm(M - M_hat)









