import os
import numpy as np
import cv2
from skimage.feature import canny
import pywt
import matplotlib.pyplot as plt
import torch

gray_images = []
symlets_images = []
haar_images = []
daubechies_images = []
coiflets_images = []
labels = []

path = './Yale-B'
Render = False

for img_file in sorted(os.listdir(path)):
    img_path = os.path.join(path, img_file)
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    # img = cv2.resize(img, (64, 64), interpolation=cv2.INTER_LINEAR)

    label = int(img_file.split('_')[0].split('B')[1])
    # 取文件名的前7位作为标签
    labels.append(label)

    edges = canny(img, sigma=1)


    coeffs = pywt.dwt2(img, 'haar')
    haar = coeffs[0]
    coeffs = pywt.dwt2(img, 'haar')
    haar = coeffs[0]

    coeffs = pywt.dwt2(img, 'db2')
    daubechies = coeffs[0]
    coeffs = pywt.dwt2(img, 'db2')
    daubechies = coeffs[0]

    coeffs = pywt.dwt2(img, 'coif1')
    coiflets = coeffs[0]
    coeffs = pywt.dwt2(img, 'coif1')
    coiflets = coeffs[0]

    coeffs = pywt.dwt2(img, 'sym2')
    symlets = coeffs[0]
    coeffs = pywt.dwt2(img, 'sym2')
    symlets = coeffs[0]

    # haar = cv2.resize(haar, (32, 32), interpolation=cv2.INTER_LINEAR)
    # daubechies = cv2.resize(daubechies, (32, 32), interpolation=cv2.INTER_LINEAR)
    # coiflets = cv2.resize(coiflets, (32, 32), interpolation=cv2.INTER_LINEAR)
    # symlets = cv2.resize(symlets, (32, 32), interpolation=cv2.INTER_LINEAR)

    # # 将图像和特征添加到列表
    #
    # # 最大-最小归一化
    # haar_images.append(torch.from_numpy((haar - haar.min()) / (haar.max() - haar.min())).unsqueeze(0))
    # daubechies_images.append(
    #     torch.from_numpy((daubechies - daubechies.min()) / (daubechies.max() - daubechies.min())).unsqueeze(0))
    # coiflets_images.append(
    #     torch.from_numpy((coiflets - coiflets.min()) / (coiflets.max() - coiflets.min())).unsqueeze(0))
    # symlets_images.append(
    #     torch.from_numpy((symlets - symlets.min()) / (symlets.max() - symlets.min())).unsqueeze(0))

    # direct normalization
    gray_images.append(torch.from_numpy(img / 255.0).unsqueeze(0))
    haar_images.append(torch.from_numpy(haar / 255.0).unsqueeze(0))
    daubechies_images.append(torch.from_numpy(daubechies / 255.0).unsqueeze(0))
    coiflets_images.append(torch.from_numpy(coiflets / 255.0).unsqueeze(0))
    symlets_images.append(torch.from_numpy(symlets / 255.0).unsqueeze(0))


    if Render == False:
        fig, axs = plt.subplots(1, 5, figsize=(12, 6))

        for ax in axs:
            ax.axis('off')
        # 在左边的子图中渲染原始图像
        axs[0].imshow(img, cmap='gray')
        axs[0].set_title(f'Label {label}')

        # show symlets
        axs[1].imshow(symlets, cmap='gray')
        axs[1].set_title('Symlets')

        # show haar
        axs[2].imshow(haar, cmap='gray')
        axs[2].set_title('Haar')

        # show coiflets
        axs[3].imshow(coiflets, cmap='gray')
        axs[3].set_title('Coiflets')

        # show daubechies
        axs[4].imshow(daubechies, cmap='gray')
        axs[4].set_title('Daubechies')
        # 显示画布
        plt.savefig('./DataFiles/Yale-B-Face.pdf', bbox_inches='tight')
        plt.show()
        Render = True

gray_images = torch.stack(gray_images, dim=0)
symlets_images = torch.stack(symlets_images, dim=0)
haar_images = torch.stack(haar_images, dim=0)
daubechies_images = torch.stack(daubechies_images, dim=0)
coiflets_images = torch.stack(coiflets_images, dim=0)
labels = torch.tensor(labels)

# shuffle data
indices = torch.randperm(len(gray_images))
gray_images = gray_images[indices]
symlets_images = symlets_images[indices]
haar_images = haar_images[indices]
daubechies_images = daubechies_images[indices]
coiflets_images = coiflets_images[indices]
labels = labels[indices]


# save .pt files
torch.save(gray_images, './DataFiles/Yale-B-Gray.pt')
torch.save(symlets_images, './DataFiles/Yale-B-Symlets.pt')
torch.save(haar_images, './DataFiles/Yale-B-Haar.pt')
torch.save(daubechies_images, './DataFiles/Yale-B-Daubechies.pt')
torch.save(coiflets_images, './DataFiles/Yale-B-Coiflets.pt')
torch.save(labels, './DataFiles/Yale-B-Label.pt')

# save .npy files
# np.save('./DataFiles/Yale-B-Gray.npy', gray_images.numpy())
# np.save('./DataFiles/Yale-B-Canny.npy', canny_images.numpy())
# np.save('./DataFiles/Yale-B-Haar.npy', haar_images.numpy())
# np.save('./DataFiles/Yale-B-Daubechies.npy', daubechies_images.numpy())
# np.save('./DataFiles/Yale-B-Coiflets.npy', coiflets_images.numpy())
# np.save('./DataFiles/Yale-B-Label.npy', labels.numpy())

print("Done!\n")