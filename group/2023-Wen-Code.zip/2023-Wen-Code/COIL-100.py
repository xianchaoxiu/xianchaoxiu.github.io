import os
import numpy as np
import torch
from PIL import Image
import matplotlib.pyplot as plt
import cv2
# 指定图像目录
image_dir = './coil-100'

# 初始化列表来存储图像的R,G,B三个通道的分量和标签
r_images = []
g_images = []
b_images = []
labels = []

# 获取目录中所有的.png文件
png_files = [filename for filename in os.listdir(image_dir) if filename.endswith('.png')]

# 根据标签和样本顺序对文件名进行排序
sorted_files = sorted(
    png_files, key=lambda filename: (int(filename.split('__')[0].replace('obj', '')), int(filename.split('__')[1].
                                                                                          replace('.png', ''))))

Render = False
# 遍历排序后的每个文件
for filename in sorted_files:
    # 读取图像
    img = Image.open(os.path.join(image_dir, filename))
    # 将图像转换为numpy数组
    img_array = np.array(img)
    # 分离R,G,B三个通道的分量

    img_array = cv2.resize(img_array, (64, 64), interpolation=cv2.INTER_LINEAR)
    r, g, b = img_array[:, :, 0], img_array[:, :, 1], img_array[:, :, 2]

    r_images.append(torch.from_numpy(r / 255.0).unsqueeze(0))
    g_images.append(torch.from_numpy(g / 255.0).unsqueeze(0))
    b_images.append(torch.from_numpy(b / 255.0).unsqueeze(0))
    # 从文件名中提取标签（obj编号）
    label = int(filename.split('__')[0].replace('obj', ''))
    # 保存标签数据
    labels.append(label)

    if Render == False:

        fig, axs = plt.subplots(1, 4, figsize=(12, 6))

        for ax in axs:
            ax.axis('off')
        axs[0].imshow(img_array)
        axs[0].set_title(f'Label {label}')

        # 在右边的子图中渲染边缘检测后的图像
        axs[1].imshow(r)
        axs[1].set_title('R')

        # 在左边的子图中渲染原始图像
        axs[2].imshow(g)
        axs[2].set_title('G')

        # 在右边的子图中渲染边缘检测后的图像
        axs[3].imshow(b)
        axs[3].set_title('B')

        plt.savefig('./DataFiles/COIL100.pdf', bbox_inches='tight')
        plt.show()

        Render = True


# 将列表转换为numpy数组
r_images = torch.stack(r_images, dim=0)
g_images = torch.stack(g_images, dim=0)
b_images = torch.stack(b_images, dim=0)
labels = torch.tensor(labels)

# shuffle data and save to .pt files
shuffle_indices = torch.randperm(r_images.shape[0])
r_images = r_images[shuffle_indices]
g_images = g_images[shuffle_indices]
b_images = b_images[shuffle_indices]
labels = labels[shuffle_indices]

# save .npy files
# np.save('./DataFiles/COIL-100-R.npy', r_images.numpy())
# np.save('./DataFiles/COIL-100-G.npy', g_images.numpy())
# np.save('./DataFiles/COIL-100-B.npy', b_images.numpy())
# np.save('./DataFiles/COIL-100-Label.npy', labels.numpy())

# save .pt files
torch.save(r_images, './DataFiles/COIL-100-R.pt')
torch.save(g_images, './DataFiles/COIL-100-G.pt')
torch.save(b_images, './DataFiles/COIL-100-B.pt')
torch.save(labels, './DataFiles/COIL-100-Label.pt')

print("\nDone!\n")