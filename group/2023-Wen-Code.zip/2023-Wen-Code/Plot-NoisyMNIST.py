from AllDatasetLoader import getCOIL20Data, getORLFaceData, getYaleBData, getNoisyMNISTData, getNoisyEMNISTData, getNoisyFashionMNISTData
import matplotlib.pyplot as plt

noisy_mnist_train, _, _, _, _ = getNoisyMNISTData()
noisy_emnist_train, _, _, _, _ = getNoisyEMNISTData()
noisy_fashion_mnist_train, _, _, _, _ = getNoisyFashionMNISTData()

noisy_mnist_view_1 = noisy_mnist_train.view_1[:10].reshape(-1, 28, 28)
noisy_mnist_view_2 = noisy_mnist_train.view_2[:10].reshape(-1, 28, 28)
noisy_mnist_label = noisy_mnist_train.label[:10]

noisy_emnist_view_1 = noisy_emnist_train.view_1[:10].reshape(-1, 28, 28)
noisy_emnist_view_2 = noisy_emnist_train.view_2[:10].reshape(-1, 28, 28)
noisy_emnist_label = noisy_emnist_train.label[:10]

noisy_fashion_mnist_view_1 = noisy_fashion_mnist_train.view_1[:10].reshape(-1, 28, 28)
noisy_fashion_mnist_view_2 = noisy_fashion_mnist_train.view_2[:10].reshape(-1, 28, 28)
noisy_fashion_mnist_label = noisy_fashion_mnist_train.label[:10]

# plot two views of each dataset
fig, axs = plt.subplots(6, 10, figsize=(20, 12))  # 创建6行10列的subplot网格
datasets = [noisy_mnist_train, noisy_emnist_train, noisy_fashion_mnist_train]
views_1 = [noisy_mnist_view_1, noisy_emnist_view_1, noisy_fashion_mnist_view_1]
views_2 = [noisy_mnist_view_2, noisy_emnist_view_2, noisy_fashion_mnist_view_2]
labels = [noisy_mnist_label, noisy_emnist_label, noisy_fashion_mnist_label]
titles = ["Noisy MNIST", "Noisy EMNIST", "Noisy Fashion MNIST"]

for i in range(3):  # 对于每个数据集
    for j in range(10):  # 对于每个样本
        axs[2*i, j].imshow(views_1[i][j], cmap='gray')  # 显示视角1
        axs[2*i, j].axis('off')

        axs[2*i+1, j].imshow(views_2[i][j], cmap='gray')  # 显示视角2
        axs[2*i+1, j].axis('off')

plt.tight_layout()
plt.savefig('ThreeNoisyMNIST.pdf', bbox_inches='tight')  # 保存为PDF文件
plt.show()