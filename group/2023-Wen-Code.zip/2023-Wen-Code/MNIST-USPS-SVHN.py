import torch
from torchvision import datasets, transforms
from PIL import Image
import numpy as np

# 定义一个变换，将图像转换为大小为28x28的张量
transform = transforms.Compose([
    transforms.Resize((28, 28)),
    transforms.ToTensor(),
])

# 加载数据集
mnist_train = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
svhn_train = datasets.SVHN(root='./data', split='train', download=True, transform=transform)
usps_train = datasets.USPS(root='./data', train=True, download=True, transform=transform)

mnist_test = datasets.MNIST(root='./data', train=False, download=True, transform=transform)
svhn_test = datasets.SVHN(root='./data', split='test', download=True, transform=transform)
usps_test = datasets.USPS(root='./data', train=False, download=True, transform=transform)

mnist_train_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别
svhn_train_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别
usps_train_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别

mnist_test_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别
svhn_test_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别
usps_test_dict = {0: [], 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7:[], 8:[], 9:[]} # 10个类别

# 在 SVHN 中，我们将标签 10 改为 0 以使其与 MNIST 和 USPS 的标签一致
for data, label in mnist_train:
    mnist_train_dict[label].append(data)

for data, label in svhn_train:
    if label == 10:
        label = 0
    # turn svhn to gray by averaging the 3 channels
    data = np.array(data).mean(axis=0)
    data = torch.tensor(data).unsqueeze(0)
    svhn_train_dict[label].append(data)

for data, label in usps_train:
    usps_train_dict[label].append(data)

for data, label in mnist_test:
    mnist_test_dict[label].append(data)

for data, label in svhn_test:
    if label == 10:
        label = 0
    data = np.array(data).mean(axis=0)
    data = torch.tensor(data).unsqueeze(0)
    svhn_test_dict[label].append(data)

for data, label in usps_test:
    usps_test_dict[label].append(data)

out_mnist_train = []
out_svhn_train = []
out_usps_train = []
out_label_train = []

out_mnist_test = []
out_svhn_test = []
out_usps_test = []
out_label_test = []

for i in range(10):
    length = len(usps_train_dict[i])
    out_mnist_train.append(torch.stack(mnist_train_dict[i][:length], dim=0))
    out_usps_train.append(torch.stack(usps_train_dict[i][:length], dim=0))
    out_label_train.append(torch.ones(length) * i)
    # turn svhn to gray scale

    out_svhn_train.append(torch.stack(svhn_train_dict[i][:length], dim=0))

    length = len(usps_test_dict[i])
    out_mnist_test.append(torch.stack(mnist_test_dict[i][:length], dim=0))
    out_usps_test.append(torch.stack(usps_test_dict[i][:length], dim=0))
    out_label_test.append(torch.ones(length) * i)
    # turn svhn to gray scale

    out_svhn_test.append(torch.stack(svhn_test_dict[i][:length], dim=0))

out_mnist_train = torch.cat(out_mnist_train, dim=0)
out_svhn_train = torch.cat(out_svhn_train, dim=0)
out_usps_train = torch.cat(out_usps_train, dim=0)
out_label_train = torch.cat(out_label_train, dim=0)

out_mnist_test = torch.cat(out_mnist_test, dim=0)
out_svhn_test = torch.cat(out_svhn_test, dim=0)
out_usps_test = torch.cat(out_usps_test, dim=0)
out_label_test = torch.cat(out_label_test, dim=0)

# shuffle the data
idx = torch.randperm(out_mnist_train.size(0))
out_mnist_train = out_mnist_train[idx]
out_svhn_train = out_svhn_train[idx]
out_usps_train = out_usps_train[idx]
out_label_train = out_label_train[idx]

idx = torch.randperm(out_mnist_test.size(0))
out_mnist_test = out_mnist_test[idx]
out_svhn_test = out_svhn_test[idx]
out_usps_test = out_usps_test[idx]
out_label_test = out_label_test[idx]

# split train data into train, val in a 6:4 ratio
train_size = int(out_label_train.shape[0] * 0.6)
val_size = out_label_train.shape[0] - train_size

out_mnist_val = out_mnist_train[train_size:]
out_svhn_val = out_svhn_train[train_size:]
out_usps_val = out_usps_train[train_size:]
out_label_val = out_label_train[train_size:]

out_mnist_train = out_mnist_train[:train_size]
out_svhn_train = out_svhn_train[:train_size]
out_usps_train = out_usps_train[:train_size]
out_label_train = out_label_train[:train_size]

# save .pt files
torch.save(out_mnist_train, './DataFiles/ThreeDigitViews-MNIST-Train.pt')
torch.save(out_svhn_train, './DataFiles/ThreeDigitViews-SVHN-Train.pt')
torch.save(out_usps_train, './DataFiles/ThreeDigitViews-USPS-Train.pt')
torch.save(out_label_train, './DataFiles/ThreeDigitViews-Label-Train.pt')

torch.save(out_mnist_val, './DataFiles/ThreeDigitViews-MNIST-Valid.pt')
torch.save(out_svhn_val, './DataFiles/ThreeDigitViews-SVHN-Valid.pt')
torch.save(out_usps_val, './DataFiles/ThreeDigitViews-USPS-Valid.pt')
torch.save(out_label_val, './DataFiles/ThreeDigitViews-Label-Valid.pt')

torch.save(out_mnist_test, './DataFiles/ThreeDigitViews-MNIST-Test.pt')
torch.save(out_svhn_test, './DataFiles/ThreeDigitViews-SVHN-Test.pt')
torch.save(out_usps_test, './DataFiles/ThreeDigitViews-USPS-Test.pt')
torch.save(out_label_test, './DataFiles/ThreeDigitViews-Label-Test.pt')

# make some train labels to be -1, from ratio 0.05 to 0.5 with step 0.05
for ratio in np.arange(1, 101, 1):
    new_label = out_label_train.clone()
    new_label[:] = -1
    # tensor of random indices
    random_indices = torch.randperm(out_label_train.shape[0])
    # number of labels to keep
    num_labels_to_keep = int(out_label_train.shape[0] * (ratio / 100))
    print(f"{num_labels_to_keep} labels/ {out_label_train.size(0)} to keep:")
    # set labels back to their original values
    new_label[random_indices[:num_labels_to_keep]] = out_label_train[random_indices[:num_labels_to_keep]]
    # save .pt files
    torch.save(new_label, f'./DataFiles/ThreeDigitViews-Label-Train-Ratio-{int(ratio)}.pt')

# save .npy files
# np.save('./DataFiles/ThreeDigitViews-MNIST-Train.npy', out_mnist_train.numpy())
# np.save('./DataFiles/ThreeDigitViews-SVHN-Train.npy', out_svhn_train.numpy())
# np.save('./DataFiles/ThreeDigitViews-USPS-Train.npy', out_usps_train.numpy())
# np.save('./DataFiles/ThreeDigitViews-Label-Train.npy', out_label_train.numpy())
#
# np.save('./DataFiles/ThreeDigitViews-MNIST-Test.npy', out_mnist_test.numpy())
# np.save('./DataFiles/ThreeDigitViews-SVHN-Test.npy', out_svhn_test.numpy())
# np.save('./DataFiles/ThreeDigitViews-USPS-Test.npy', out_usps_test.numpy())
# np.save('./DataFiles/ThreeDigitViews-Label-Test.npy', out_label_test.numpy())

print("Done!\n")

