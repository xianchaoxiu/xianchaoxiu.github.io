import torch
from torch.utils.data import Dataset
from sklearn.decomposition import PCA
from cca_zoo.data.deep import get_dataloaders
import numpy as np
import gzip

def make_tensor(data_xy):
    data_x, data_y = data_xy
    data_x = np.array(data_x, dtype=np.float32)
    data_y = np.array(data_y, dtype=np.int32)
    return data_x, data_y


def load_pickle(f):
    try:
        import cPickle as thepickle
    except ImportError:
        import _pickle as thepickle

    try:
        ret = thepickle.load(f, encoding='latin1')
    except TypeError:
        ret = thepickle.load(f)

    return ret


def load_data(data_file):
    print('loading data ...')
    f = gzip.open(data_file, 'rb')
    train_set, valid_set, test_set = load_pickle(f)
    f.close()

    train_set_x, train_set_y = make_tensor(train_set)  # (50000, 784) (50000,)
    valid_set_x, valid_set_y = make_tensor(valid_set)  # (10000, 784) (10000,)
    test_set_x, test_set_y = make_tensor(test_set)  # (10000, 784) (10000,)

    return train_set_x, train_set_y, valid_set_x, valid_set_y, test_set_x, test_set_y
class TwoViews(Dataset):
    def __init__(self, view_1, view_2, train_label, label = None):
        self.train_label = train_label
        self.dataset_length = train_label.shape[0]
        self.label = label
        if label is None:
            self.label = train_label

        self.view_1 = view_1
        self.view_2 = view_2

    def __getitem__(self, i):
        data = {
            'x1': self.view_1[i].float(),
            'x2': self.view_2[i].float(),
            'label': self.train_label[i].long()
        }

        return data

    def __len__(self):
        return self.dataset_length

class ThreeViews(Dataset):
    def __init__(self, view_1, view_2, view_3, train_label, label = None):
        self.train_label = train_label
        self.dataset_length = train_label.shape[0]
        self.label = label

        if label is None:
            self.label = train_label

        self.view_1 = view_1
        self.view_2 = view_2
        self.view_3 = view_3

    def __getitem__(self, i):
        data = {
            'x1': self.view_1[i].float(),
            'x2': self.view_2[i].float(),
            'x3': self.view_3[i].float(),
            'label': self.train_label[i].long()
        }

        return data

    def __len__(self):
        return self.dataset_length
class SixViews(Dataset):
    def __init__(self, v1, v2, v3, v4, v5, v6, train_label, label = None):
        self.train_label = train_label
        self.dataset_length = train_label.shape[0]
        self.label = label

        if label is None:
            self.label = train_label

        self.v1 = v1
        self.v2 = v2
        self.v3 = v3
        self.v4 = v4
        self.v5 = v5
        self.v6 = v6
    def __getitem__(self, item):
        data = {
            'x1': self.v1[item].float(),
            'x2': self.v2[item].float(),
            'x3': self.v3[item].float(),
            'x4': self.v4[item].float(),
            'x5': self.v5[item].float(),
            'x6': self.v6[item].float(),
            'label': self.train_label[item].long(),
            'index': item
        }
        return data
    def __len__(self):
        return self.dataset_length
class TwoViewsZoo(Dataset):
    def __init__(self, view_1, view_2, train_label, label = None):
        self.train_label = train_label
        self.dataset_length = train_label.shape[0]
        self.label = label
        if label is None:
            self.label = train_label

        self.view_1 = view_1
        self.view_2 = view_2

    def __getitem__(self, i):
        return {
            'views': (self.view_1[i].float(), self.view_2[i].float()),
            'label': self.train_label[i],
            'index': i
        }

    def __len__(self):
        return self.dataset_length

class ThreeViewsZoo(Dataset):
    def __init__(self, view_1, view_2, view_3, train_label, label = None):
        self.train_label = train_label
        self.dataset_length = train_label.shape[0]
        self.label = label
        if label is None:
            self.label = train_label

        self.view_1 = view_1
        self.view_2 = view_2
        self.view_3 = view_3

    def __getitem__(self, i):
        return {
            'views': (self.view_1[i].float(), self.view_2[i].float(), self.view_3[i].float()),
            'label': self.train_label[i],
            'index': i
        }

    def __len__(self):
        return self.dataset_length

def getNoisyMNISTData(flatten: bool = True, zoo: bool = False, label_ratio: int = 100):
    assert label_ratio >= 0 and label_ratio <= 100
    # read noisy mnist .pt data
    mnist_original_train = torch.load("./DataFiles/Noisy-MNIST-Original-Train.pt")
    mnist_noise_train = torch.load("./DataFiles/Noisy-MNIST-Noise-Train.pt")
    mnist_label_train = torch.load("./DataFiles/Noisy-MNIST-Label-Train.pt")

    val_original = torch.load("./DataFiles/Noisy-MNIST-Original-Val.pt")
    val_noise = torch.load("./DataFiles/Noisy-MNIST-Noise-Val.pt")
    val_label = torch.load("./DataFiles/Noisy-MNIST-Label-Val.pt")

    mnist_original_test = torch.load("./DataFiles/Noisy-MNIST-Original-Test.pt")
    mnist_noise_test = torch.load("./DataFiles/Noisy-MNIST-Noise-Test.pt")
    mnist_label_test = torch.load("./DataFiles/Noisy-MNIST-Label-Test.pt")

    # flatten data if flatten is True
    if flatten:
        mnist_original_train = torch.flatten(mnist_original_train, start_dim=1)
        mnist_noise_train = torch.flatten(mnist_noise_train, start_dim=1)

        val_original = torch.flatten(val_original, start_dim=1)
        val_noise = torch.flatten(val_noise, start_dim=1)

        mnist_original_test = torch.flatten(mnist_original_test, start_dim=1)
        mnist_noise_test = torch.flatten(mnist_noise_test, start_dim=1)

    # according to label_ratio, randomly set some labels from train_label to -1 (unlabeled)
    train_label = mnist_label_train
    if label_ratio < 100:
        train_label = torch.load(f"./DataFiles/Noisy-MNIST-Label-Train-Ratio-{label_ratio}.pt")

    # create train, val and test datasets
    if zoo:
        train_dataset = TwoViewsZoo(mnist_original_train, mnist_noise_train, train_label, mnist_label_train)
        val_dataset = TwoViewsZoo(val_original, val_noise, val_label)
        test_dataset = TwoViewsZoo(mnist_original_test, mnist_noise_test, mnist_label_test)
    else:
        train_dataset = TwoViews(mnist_original_train, mnist_noise_train, train_label, mnist_label_train)
        val_dataset = TwoViews(val_original, val_noise, val_label)
        test_dataset = TwoViews(mnist_original_test, mnist_noise_test, mnist_label_test)

    # get view_1 and view_2 shapes torch.size()
    view_1_shape = mnist_original_train.shape[1:]
    view_2_shape = mnist_noise_train.shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape

def getNoisyFashionMNISTData(flatten: bool = True, zoo: bool = False, label_ratio: int = 100):
    assert label_ratio >= 0 and label_ratio <= 100
    # read noisy fashion mnist .pt data
    fashion_mnist_original_train = torch.load("./DataFiles/Noisy-Fashion-MNIST-Original-Train.pt")
    fashion_mnist_noise_train = torch.load("./DataFiles/Noisy-Fashion-MNIST-Noise-Train.pt")
    fashion_mnist_label_train = torch.load("./DataFiles/Noisy-Fashion-MNIST-Label-Train.pt")

    fashion_mnist_original_val = torch.load("./DataFiles/Noisy-Fashion-MNIST-Original-Val.pt")
    fashion_mnist_noise_val = torch.load("./DataFiles/Noisy-Fashion-MNIST-Noise-Val.pt")
    fashion_mnist_label_val = torch.load("./DataFiles/Noisy-Fashion-MNIST-Label-Val.pt")

    fashion_mnist_original_test = torch.load("./DataFiles/Noisy-Fashion-MNIST-Original-Test.pt")
    fashion_mnist_noise_test = torch.load("./DataFiles/Noisy-Fashion-MNIST-Noise-Test.pt")
    fashion_mnist_label_test = torch.load("./DataFiles/Noisy-Fashion-MNIST-Label-Test.pt")
    # flatten data if flatten is True
    if flatten:
        fashion_mnist_original_train = torch.flatten(fashion_mnist_original_train, start_dim=1)
        fashion_mnist_noise_train = torch.flatten(fashion_mnist_noise_train, start_dim=1)
        fashion_mnist_original_val = torch.flatten(fashion_mnist_original_val, start_dim=1)
        fashion_mnist_noise_val = torch.flatten(fashion_mnist_noise_val, start_dim=1)
        fashion_mnist_original_test = torch.flatten(fashion_mnist_original_test, start_dim=1)
        fashion_mnist_noise_test = torch.flatten(fashion_mnist_noise_test, start_dim=1)

    # according to label_ratio, randomly set some labels from train_label to -1 (unlabeled)
    train_label = fashion_mnist_label_train
    if label_ratio < 100:
        train_label = torch.load(f"./DataFiles/Noisy-Fashion-MNIST-Label-Train-Ratio-{label_ratio}.pt")

    # create train, val and test datasets
    if zoo:
        train_dataset = TwoViewsZoo(fashion_mnist_original_train, fashion_mnist_noise_train, train_label, fashion_mnist_label_train)
        val_dataset = TwoViewsZoo(fashion_mnist_original_val, fashion_mnist_noise_val, fashion_mnist_label_val)
        test_dataset = TwoViewsZoo(fashion_mnist_original_test, fashion_mnist_noise_test, fashion_mnist_label_test)
    else:
        train_dataset = TwoViews(fashion_mnist_original_train, fashion_mnist_noise_train, train_label, fashion_mnist_label_train)
        val_dataset = TwoViews(fashion_mnist_original_val, fashion_mnist_noise_val, fashion_mnist_label_val)
        test_dataset = TwoViews(fashion_mnist_original_test, fashion_mnist_noise_test, fashion_mnist_label_test)

    # get view_1 and view_2 shape
    view_1_shape = fashion_mnist_original_train.shape[1:]
    view_2_shape = fashion_mnist_noise_train.shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape

def getNoisyEMNISTData(flatten: bool = True, zoo: bool = False, label_ratio: int = 100):
    assert label_ratio >= 0 and label_ratio <= 100
    # read noisy emnist .pt data
    category = 'Letters'
    emnist_original_train = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Original-Train.pt")
    emnist_original_test = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Original-Test.pt")
    emnist_noise_train = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Noise-Train.pt")
    emnist_noise_test = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Noise-Test.pt")
    emnist_label_train = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Label-Train.pt")
    emnist_label_test = torch.load(f"./DataFiles/Noisy-EMNIST-{category}-Label-Test.pt")
    # get classes of label
    classes = torch.unique(emnist_label_train)

    # split train data into train and val sets in an 8:2 ratio
    train_original, val_original = torch.split(emnist_original_train, [int(emnist_original_train.shape[0]*0.8), int(emnist_original_train.shape[0]*0.2)])
    train_noise, val_noise = torch.split(emnist_noise_train, [int(emnist_noise_train.shape[0]*0.8), int(emnist_noise_train.shape[0]*0.2)])
    train_label, val_label = torch.split(emnist_label_train, [int(emnist_label_train.shape[0]*0.8), int(emnist_label_train.shape[0]*0.2)])
    train_label_original = train_label.clone()
    # flatten data if flatten is True
    if flatten:
        train_original = torch.flatten(train_original, start_dim=1)
        val_original = torch.flatten(val_original, start_dim=1)
        train_noise = torch.flatten(train_noise, start_dim=1)
        val_noise = torch.flatten(val_noise, start_dim=1)
        emnist_original_test = torch.flatten(emnist_original_test, start_dim=1)
        emnist_noise_test = torch.flatten(emnist_noise_test, start_dim=1)

    # according to label_ratio, randomly set some labels from train_label to -1 (unlabeled)
    if label_ratio < 100:
        # tensor of random indices
        random_indices = torch.randperm(train_label.shape[0])
        # number of labels to be set to -1
        num_labels = int(train_label.shape[0] * (1.0 - label_ratio))
        # set labels to -1
        train_label[random_indices[:num_labels]] = -1

    # create train, val and test datasets
    if zoo:
        train_dataset = TwoViewsZoo(train_original, train_noise, train_label, train_label_original)
        val_dataset = TwoViewsZoo(val_original, val_noise, val_label)
        test_dataset = TwoViewsZoo(emnist_original_test, emnist_noise_test, emnist_label_test)
    else:
        train_dataset = TwoViews(train_original, train_noise, train_label, train_label_original)
        val_dataset = TwoViews(val_original, val_noise, val_label)
        test_dataset = TwoViews(emnist_original_test, emnist_noise_test, emnist_label_test)

    # get view_1 and view_2 shape
    view_1_shape = train_original.shape[1:]
    view_2_shape = train_noise.shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape

def getCOIL20Data(view_1 = "gray", view_2 = "haar", flatten: bool = True, zoo: bool = False):
    # read coil20 .pt data
    gray = torch.load("./DataFiles/COIL-20-Gray.pt")
    haar = torch.load("./DataFiles/COIL-20-Haar.pt")
    coiflets = torch.load("./DataFiles/COIL-20-Coiflets.pt")
    daubechies = torch.load("./DataFiles/COIL-20-Daubechies.pt")
    symlets = torch.load("./DataFiles/COIL-20-Symlets.pt")

    label = torch.load("./DataFiles/COIL-20-Label.pt")

    # split data into train, val and test sets in a 5:1:4 ratio
    train_size = int(gray.shape[0]*0.5)
    val_size = int(gray.shape[0]*0.1)
    test_size = gray.shape[0] - train_size - val_size

    train_gray, val_gray, test_gray = torch.split(gray, [train_size, val_size, test_size])
    train_haar, val_haar, test_haar = torch.split(haar, [train_size, val_size, test_size])
    train_coiflets, val_coiflets, test_coiflets = torch.split(coiflets, [train_size, val_size, test_size])
    train_daubechies, val_daubechies, test_daubechies = torch.split(daubechies, [train_size, val_size, test_size])
    train_symlets, val_symlets, test_symlets = torch.split(symlets, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])

    # create train, val and test datasets
    train_views = {"symlets": train_symlets, "coiflets": train_coiflets, "daubechies": train_daubechies, "gray": train_gray, "haar": train_haar}
    val_views = {"symlets": val_symlets, "coiflets": val_coiflets, "daubechies": val_daubechies, "gray": val_gray, "haar": val_haar}
    test_views = {"symlets": test_symlets, "coiflets": test_coiflets, "daubechies": test_daubechies, "gray": test_gray, "haar": test_haar}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width)
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = TwoViewsZoo(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViewsZoo(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViewsZoo(test_views[view_1], test_views[view_2], test_label)
    else:
        train_dataset = TwoViews(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViews(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViews(test_views[view_1], test_views[view_2], test_label)

    # get view_1 and view_2 shape
    view_1_shape = train_views[view_1].shape[1:]
    view_2_shape = train_views[view_2].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape


def getCOIL100Data(flatten: bool = True, zoo: bool = False):
    # read coil100 .pt data
    r = torch.load("./DataFiles/COIL-100-R.pt")
    g = torch.load("./DataFiles/COIL-100-G.pt")
    b = torch.load("./DataFiles/COIL-100-B.pt")
    label = torch.load("./DataFiles/COIL-100-Label.pt")

    # split data into train, val and test sets in a 6:2:2 ratio
    train_r, val_r, test_r = torch.split(r, [int(r.shape[0]*0.6), int(r.shape[0]*0.2), int(r.shape[0]*0.2)])
    train_g, val_g, test_g = torch.split(g, [int(g.shape[0]*0.6), int(g.shape[0]*0.2), int(g.shape[0]*0.2)])
    train_b, val_b, test_b = torch.split(b, [int(b.shape[0]*0.6), int(b.shape[0]*0.2), int(b.shape[0]*0.2)])
    train_label, val_label, test_label = torch.split(label, [int(label.shape[0]*0.6), int(label.shape[0]*0.2), int(label.shape[0]*0.2)])

    # create train, val and test datasets
    train_views = {"r": train_r, "g": train_g, "b": train_b}
    val_views = {"r": val_r, "g": val_g, "b": val_b}
    test_views = {"r": test_r, "g": test_g, "b": test_b}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = ThreeViewsZoo(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViewsZoo(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViewsZoo(test_views["r"], test_views["g"], test_views["b"], test_label)
    else:
        train_dataset = ThreeViews(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViews(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViews(test_views["r"], test_views["g"], test_views["b"], test_label)

    # get view_1, view_2, view_3 shape
    view_1_shape = train_views["r"].shape[1:]
    view_2_shape = train_views["g"].shape[1:]
    view_3_shape = train_views["b"].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape, view_3_shape


def getETH80AllData(flatten: bool = True, zoo: bool = False):
    # read ETH80 .pt data
    r = torch.load("./DataFiles/ETH-80-All-R.pt")
    g = torch.load("./DataFiles/ETH-80-All-G.pt")
    b = torch.load("./DataFiles/ETH-80-All-B.pt")
    label = torch.load("./DataFiles/ETH-80-All-Label.pt")

    # split data into train, val and test sets in a 6:2:2 ratio
    train_r, val_r, test_r = torch.split(r, [int(r.shape[0]*0.6), int(r.shape[0]*0.2), int(r.shape[0]*0.2)])
    train_g, val_g, test_g = torch.split(g, [int(g.shape[0]*0.6), int(g.shape[0]*0.2), int(g.shape[0]*0.2)])
    train_b, val_b, test_b = torch.split(b, [int(b.shape[0]*0.6), int(b.shape[0]*0.2), int(b.shape[0]*0.2)])
    train_label, val_label, test_label = torch.split(label, [int(label.shape[0]*0.6), int(label.shape[0]*0.2), int(label.shape[0]*0.2)])

    # create train, val and test datasets
    train_views = {"r": train_r, "g": train_g, "b": train_b}
    val_views = {"r": val_r, "g": val_g, "b": val_b}
    test_views = {"r": test_r, "g": test_g, "b": test_b}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = ThreeViewsZoo(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViewsZoo(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViewsZoo(test_views["r"], test_views["g"], test_views["b"], test_label)
    else:
        train_dataset = ThreeViews(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViews(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViews(test_views["r"], test_views["g"], test_views["b"], test_label)

    # get view_1, view_2, view_3 shape
    view_1_shape = train_views["r"].shape[1:]
    view_2_shape = train_views["g"].shape[1:]
    view_3_shape = train_views["b"].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape, view_3_shape

def getETH80Data(type="Apple", flatten: bool = True, zoo: bool = False):
    r = torch.load(f"./DataFiles/ETH-80-{type}-R.pt")
    g = torch.load(f"./DataFiles/ETH-80-{type}-G.pt")
    b = torch.load(f"./DataFiles/ETH-80-{type}-B.pt")
    label = torch.load(f"./DataFiles/ETH-80-{type}-Label.pt")

    # split data into train, val and test sets in a 6:2:2 ratio
    train_r, val_r, test_r = torch.split(r, [int(r.shape[0] * 0.6), int(r.shape[0] * 0.2), int(r.shape[0] * 0.2)])
    train_g, val_g, test_g = torch.split(g, [int(g.shape[0] * 0.6), int(g.shape[0] * 0.2), int(g.shape[0] * 0.2)])
    train_b, val_b, test_b = torch.split(b, [int(b.shape[0] * 0.6), int(b.shape[0] * 0.2), int(b.shape[0] * 0.2)])
    train_label, val_label, test_label = torch.split(label, [int(label.shape[0] * 0.6), int(label.shape[0] * 0.2),
                                                             int(label.shape[0] * 0.2)])

    # create train, val and test datasets
    train_views = {"r": train_r, "g": train_g, "b": train_b}
    val_views = {"r": val_r, "g": val_g, "b": val_b}
    test_views = {"r": test_r, "g": test_g, "b": test_b}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = ThreeViewsZoo(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViewsZoo(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViewsZoo(test_views["r"], test_views["g"], test_views["b"], test_label)
    else:
        train_dataset = ThreeViews(train_views["r"], train_views["g"], train_views["b"], train_label)
        val_dataset = ThreeViews(val_views["r"], val_views["g"], val_views["b"], val_label)
        test_dataset = ThreeViews(test_views["r"], test_views["g"], test_views["b"], test_label)

    # get view_1, view_2, view_3 shape
    view_1_shape = train_views["r"].shape[1:]
    view_2_shape = train_views["g"].shape[1:]
    view_3_shape = train_views["b"].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape, view_3_shape

def getORLFaceData(view_1 = "gray", view_2 = "haar", flatten: bool = True, zoo: bool = False):
    coiflets = torch.load("./DataFiles/ORL-Face-Coiflets.pt")
    daubechies = torch.load("./DataFiles/ORL-Face-Daubechies.pt")
    symlets = torch.load("./DataFiles/ORL-Face-Symlets.pt")
    gray = torch.load("./DataFiles/ORL-Face-Gray.pt")
    haar = torch.load("./DataFiles/ORL-Face-Haar.pt")
    label = torch.load("./DataFiles/ORL-Face-Label.pt")

    # split data into train, val and test sets in a 5:1:4 ratio
    train_size = int(label.shape[0] * 0.5)
    val_size = int(label.shape[0] * 0.1)
    test_size = label.shape[0] - train_size - val_size

    train_coiflets, val_coiflets, test_coiflets = torch.split(coiflets, [train_size, val_size, test_size])
    train_daubechies, val_daubechies, test_daubechies = torch.split(daubechies, [train_size, val_size, test_size])
    train_symlets, val_symlets, test_symlets = torch.split(symlets, [train_size, val_size, test_size])
    train_gray, val_gray, test_gray = torch.split(gray, [train_size, val_size, test_size])
    train_haar, val_haar, test_haar = torch.split(haar, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])

    # create train, val and test datasets
    train_views = {"symlets": train_symlets, "coiflets": train_coiflets, "daubechies": train_daubechies, "gray": train_gray, "haar": train_haar}
    val_views = {"symlets": val_symlets, "coiflets": val_coiflets, "daubechies": val_daubechies, "gray": val_gray, "haar": val_haar}
    test_views = {"symlets": test_symlets, "coiflets": test_coiflets, "daubechies": test_daubechies, "gray": test_gray, "haar": test_haar}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width)
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = TwoViewsZoo(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViewsZoo(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViewsZoo(test_views[view_1], test_views[view_2], test_label)
    else:
        train_dataset = TwoViews(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViews(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViews(test_views[view_1], test_views[view_2], test_label)

    # get view_1 and view_2 shape
    view_1_shape = train_views[view_1].shape[1:]
    view_2_shape = train_views[view_2].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape

def getThreeDigitViewsData(flatten: bool = True, zoo: bool = False, label_ratio: int = 100):
    assert label_ratio >= 0 and label_ratio <= 100
    #check label_ratio is a multiple of 5
    train_mnist = torch.load("./DataFiles/ThreeDigitViews-MNIST-Train.pt")
    train_usps = torch.load("./DataFiles/ThreeDigitViews-USPS-Train.pt")
    train_svhn = torch.load("./DataFiles/ThreeDigitViews-SVHN-Train.pt")
    train_label = torch.load("./DataFiles/ThreeDigitViews-Label-Train.pt")

    val_mnist = torch.load("./DataFiles/ThreeDigitViews-MNIST-Valid.pt")
    val_usps = torch.load("./DataFiles/ThreeDigitViews-USPS-Valid.pt")
    val_svhn = torch.load("./DataFiles/ThreeDigitViews-SVHN-Valid.pt")
    val_label = torch.load("./DataFiles/ThreeDigitViews-Label-Valid.pt")

    mnist_test = torch.load("./DataFiles/ThreeDigitViews-MNIST-Test.pt")
    usps_test = torch.load("./DataFiles/ThreeDigitViews-USPS-Test.pt")
    svhn_test = torch.load("./DataFiles/ThreeDigitViews-SVHN-Test.pt")
    label_test = torch.load("./DataFiles/ThreeDigitViews-Label-Test.pt")

    # create train, val and test datasets
    train_views = {"mnist": train_mnist, "usps": train_usps, "svhn": train_svhn}
    val_views = {"mnist": val_mnist, "usps": val_usps, "svhn": val_svhn}
    test_views = {"mnist": mnist_test, "usps": usps_test, "svhn": svhn_test}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width)
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    real_train_lable = train_label
    if label_ratio < 100:
        real_train_lable = torch.load(f"./DataFiles/ThreeDigitViews-Label-Train-Ratio-{label_ratio}.pt")

    if zoo:
        train_dataset = ThreeViewsZoo(train_views["mnist"], train_views["usps"], train_views["svhn"], real_train_lable, train_label)
        val_dataset = ThreeViewsZoo(val_views["mnist"], val_views["usps"], val_views["svhn"], val_label)
        test_dataset = ThreeViewsZoo(test_views["mnist"], test_views["usps"], test_views["svhn"], label_test)
    else:
        train_dataset = ThreeViews(train_views["mnist"], train_views["usps"], train_views["svhn"], real_train_lable, train_label)
        val_dataset = ThreeViews(val_views["mnist"], val_views["usps"], val_views["svhn"], val_label)
        test_dataset = ThreeViews(test_views["mnist"], test_views["usps"], test_views["svhn"], label_test)

    # get view_1, view_2 and view_3 shape
    view_1_shape = train_views["mnist"].shape[1:]
    view_2_shape = train_views["usps"].shape[1:]
    view_3_shape = train_views["svhn"].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape, view_3_shape

def getYaleBData(view_1 = "gray", view_2 = "haar", flatten: bool = True, zoo: bool = False):
    coiflets = torch.load("./DataFiles/Yale-B-Coiflets.pt")
    daubechies = torch.load("./DataFiles/Yale-B-Daubechies.pt")
    symlets = torch.load("./DataFiles/Yale-B-Symlets.pt")
    gray = torch.load("./DataFiles/Yale-B-Gray.pt")
    haar = torch.load("./DataFiles/Yale-B-Haar.pt")
    label = torch.load("./DataFiles/Yale-B-Label.pt")

    # split data into train, val and test sets in a 5:1:4 ratio
    train_size = int(gray.shape[0] * 0.5)
    val_size = int(gray.shape[0] * 0.1)
    test_size = gray.shape[0] - train_size - val_size

    train_symlets, val_symlets, test_symlets = torch.split(symlets, [train_size, val_size, test_size])
    train_coiflets, val_coiflets, test_coiflets = torch.split(coiflets, [train_size, val_size, test_size])
    train_daubechies, val_daubechies, test_daubechies = torch.split(daubechies, [train_size, val_size, test_size])
    train_gray, val_gray, test_gray = torch.split(gray, [train_size, val_size, test_size])
    train_haar, val_haar, test_haar = torch.split(haar, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])

    # create train, val and test datasets
    train_views = {"symlets": train_symlets, "coiflets": train_coiflets, "daubechies": train_daubechies, "gray": train_gray, "haar": train_haar}
    val_views = {"symlets": val_symlets, "coiflets": val_coiflets, "daubechies": val_daubechies, "gray": val_gray, "haar": val_haar}
    test_views = {"symlets": test_symlets, "coiflets": test_coiflets, "daubechies": test_daubechies, "gray": test_gray, "haar": test_haar}

    # flatten specific view, (sample_count, channel, height, width) -> (sample_count, channel * height * width)
    if flatten:
        for view in train_views:
            train_views[view] = train_views[view].reshape(train_views[view].shape[0], -1)
        for view in val_views:
            val_views[view] = val_views[view].reshape(val_views[view].shape[0], -1)
        for view in test_views:
            test_views[view] = test_views[view].reshape(test_views[view].shape[0], -1)

    if zoo:
        train_dataset = TwoViewsZoo(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViewsZoo(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViewsZoo(test_views[view_1], test_views[view_2], test_label)
    else:
        train_dataset = TwoViews(train_views[view_1], train_views[view_2], train_label)
        val_dataset = TwoViews(val_views[view_1], val_views[view_2], val_label)
        test_dataset = TwoViews(test_views[view_1], test_views[view_2], test_label)

    # get view_1 and view_2 shape
    view_1_shape = train_views[view_1].shape[1:]
    view_2_shape = train_views[view_2].shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape

def randomDropSamplesTo(dataset, sample_count):
    if isinstance(dataset, TwoViews):
        # random drop same index sample use pytorch
        indices = torch.randperm(dataset.view_1.shape[0])[:sample_count]
        dataset.view_1 = dataset.view_1[indices]
        dataset.view_2 = dataset.view_2[indices]
        dataset.train_label = dataset.train_label[indices]
        dataset.label = dataset.label[indices]
        dataset.dataset_length = sample_count
    elif isinstance(dataset, ThreeViews):
        # random drop same index sample use pytorch
        indices = torch.randperm(dataset.view_1.shape[0])[:sample_count]
        dataset.view_1 = dataset.view_1[indices]
        dataset.view_2 = dataset.view_2[indices]
        dataset.view_3 = dataset.view_3[indices]
        dataset.train_label = dataset.train_label[indices]
        dataset.label = dataset.label[indices]
        dataset.dataset_length = sample_count
def getMFDAll():
    dataset_view_1 = torch.load("./DataFiles/UCI-MFD-View-1.pt")
    dataset_view_2 = torch.load("./DataFiles/UCI-MFD-View-2.pt")
    dataset_view_3 = torch.load("./DataFiles/UCI-MFD-View-3.pt")
    dataset_view_4 = torch.load("./DataFiles/UCI-MFD-View-4.pt")
    dataset_view_5 = torch.load("./DataFiles/UCI-MFD-View-5.pt")
    dataset_view_6 = torch.load("./DataFiles/UCI-MFD-View-6.pt")
    label = torch.load("./DataFiles/UCI-MFD-Labels.pt")
    # split data into train, val and test sets in a 6:2:2 ratio
    train_size = int(dataset_view_1.shape[0] * 0.6)
    val_test_size = dataset_view_1.shape[0] - train_size
    val_size = test_size = val_test_size // 2

    train_view_1, val_view_1, test_view_1 = torch.split(dataset_view_1, [train_size, val_size, test_size])
    train_view_2, val_view_2, test_view_2 = torch.split(dataset_view_2, [train_size, val_size, test_size])
    train_view_3, val_view_3, test_view_3 = torch.split(dataset_view_3, [train_size, val_size, test_size])
    train_view_4, val_view_4, test_view_4 = torch.split(dataset_view_4, [train_size, val_size, test_size])
    train_view_5, val_view_5, test_view_5 = torch.split(dataset_view_5, [train_size, val_size, test_size])
    train_view_6, val_view_6, test_view_6 = torch.split(dataset_view_6, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])

    train_set = SixViews(train_view_1, train_view_2, train_view_3, train_view_4, train_view_5, train_view_6, train_label)
    val_set = SixViews(val_view_1, val_view_2, val_view_3, val_view_4, val_view_5, val_view_6, val_label)
    test_set = SixViews(test_view_1, test_view_2, test_view_3, test_view_4, test_view_5, test_view_6, test_label)

    # get shape of v1,v2,v3,v4,v5,v6
    view_1_shape = train_view_1.shape[1:]
    view_2_shape = train_view_2.shape[1:]
    view_3_shape = train_view_3.shape[1:]
    view_4_shape = train_view_4.shape[1:]
    view_5_shape = train_view_5.shape[1:]
    view_6_shape = train_view_6.shape[1:]

    return train_set, val_set, test_set, view_1_shape, view_2_shape, \
        view_3_shape, view_4_shape, view_5_shape, view_6_shape


def getMFDData3(view_1 = 1, view_2 = 2, view_3 = 3):
    assert view_1 != view_2, "view_1 and view_2 must be different"
    assert view_1 != view_3, "view_1 and view_3 must be different"
    assert view_2 != view_3, "view_2 and view_3 must be different"

    dataset_view_1 = torch.load(f"./DataFiles/UCI-MFD-View-{view_1}.pt")
    dataset_view_2 = torch.load(f"./DataFiles/UCI-MFD-View-{view_2}.pt")
    dataset_view_3 = torch.load(f"./DataFiles/UCI-MFD-View-{view_3}.pt")
    label = torch.load("./DataFiles/UCI-MFD-Label.pt")

    # split data into train, val and test sets in a 6:2:2 ratio
    train_size = int(dataset_view_1.shape[0] * 0.6)
    val_test_size = dataset_view_1.shape[0] - train_size
    val_size = test_size = val_test_size // 2

    train_view_1, val_view_1, test_view_1 = torch.split(dataset_view_1, [train_size, val_size, test_size])
    train_view_2, val_view_2, test_view_2 = torch.split(dataset_view_2, [train_size, val_size, test_size])
    train_view_3, val_view_3, test_view_3 = torch.split(dataset_view_3, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])


    # create train, val and test datasets
    train_dataset = ThreeViews(train_view_1, train_view_2, train_view_3, train_label)
    val_dataset = ThreeViews(val_view_1, val_view_2, val_view_3, val_label)
    test_dataset = ThreeViews(test_view_1, test_view_2, test_view_3, test_label)

    # get view_1 and view_2 shape and view_3 shape
    view_1_shape = train_view_1.shape[1:]
    view_2_shape = train_view_2.shape[1:]
    view_3_shape = train_view_3.shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape, view_3_shape


def getMFDData(view_1 = 1, view_2 = 2, zoo: bool = False):
    # load data
    assert view_1 != view_2, "view_1 and view_2 must be different"
    assert view_1 in [1, 2, 3, 4, 5, 6], "view_1 must be in [1, 2, 3, 4, 5, 6]"
    assert view_2 in [1, 2, 3, 4, 5, 6], "view_2 must be in [1, 2, 3, 4, 5, 6]"

    dataset_view_1 = torch.load(f"./DataFiles/UCI-MFD-View-{view_1}.pt")
    dataset_view_2 = torch.load(f"./DataFiles/UCI-MFD-View-{view_2}.pt")
    label = torch.load("./DataFiles/UCI-MFD-Labels.pt")

    # split data into train, val and test sets in a 6:2:2 ratio
    train_size = int(dataset_view_1.shape[0] * 0.6)
    val_test_size = dataset_view_1.shape[0] - train_size
    val_size = test_size = val_test_size // 2

    train_view_1, val_view_1, test_view_1 = torch.split(dataset_view_1, [train_size, val_size, test_size])
    train_view_2, val_view_2, test_view_2 = torch.split(dataset_view_2, [train_size, val_size, test_size])
    train_label, val_label, test_label = torch.split(label, [train_size, val_size, test_size])

    # create train, val and test datasets
    if zoo:
        train_dataset = TwoViewsZoo(train_view_1, train_view_2, train_label)
        val_dataset = TwoViewsZoo(val_view_1, val_view_2, val_label)
        test_dataset = TwoViewsZoo(test_view_1, test_view_2, test_label)
    else:
        train_dataset = TwoViews(train_view_1, train_view_2, train_label)
        val_dataset = TwoViews(val_view_1, val_view_2, val_label)
        test_dataset = TwoViews(test_view_1, test_view_2, test_label)

    # get view_1 and view_2 shape
    view_1_shape = train_view_1.shape[1:]
    view_2_shape = train_view_2.shape[1:]

    return train_dataset, val_dataset, test_dataset, view_1_shape, view_2_shape