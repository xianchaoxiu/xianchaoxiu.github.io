import torch.nn as nn
import torch.nn.functional as F
from torchvision.models.resnet import resnet18, resnet34, resnet50
from torchvision.models.vgg import vgg11, vgg16
from torchvision.models.alexnet import alexnet

class MLP(nn.Module):
    def __init__(self, chan):
        super().__init__()
        layers = nn.ModuleList([])
        cin = chan[0]
        for cout in chan[1:-1]:
            layers.append(nn.Linear(cin, cout))
            layers.append(nn.BatchNorm1d(cout))
            layers.append(nn.LeakyReLU())
            cin = cout
        layers.append(nn.Linear(cin, chan[-1]))
        self.model = nn.Sequential(*layers)
        self.latent_dim = chan[-1]
        self.input_dim = chan[0]

    def forward(self, x):
        return self.model(x)

class Residual(nn.Module):
    def __init__(self, in_channels,num_channels, strides=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels,num_channels, kernel_size=3, padding=1, stride=strides)
        self.conv2 = nn.Conv2d(num_channels,num_channels, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(in_channels, num_channels, kernel_size=1, stride=strides)

        self.bn1 = nn.BatchNorm2d(num_channels)
        self.bn2 = nn.BatchNorm2d(num_channels)

    def forward(self, X):
        Y = F.leaky_relu(self.bn1(self.conv1(X)))
        Y = self.bn2(self.conv2(Y))
        X = self.conv3(X)
        Y += X

        return F.relu(Y)

class ResNet(nn.Module):
    def __init__(self, latent_dim):
        super().__init__()
        num_channels = [32, 64, 128]

        self.conv1 = nn.Conv2d(1, num_channels[0], kernel_size=7, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(num_channels[0])
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.res1 = Residual(num_channels[0], num_channels[1])
        self.res2 = Residual(num_channels[1], num_channels[2])
        self.fc = nn.Linear(num_channels[2], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, X):
        Y = F.leaky_relu(self.bn1(self.conv1(X)))
        Y = self.pool1(Y)
        Y = self.res1(Y)
        Y = self.res2(Y)
        Y = F.adaptive_avg_pool2d(Y, (1, 1)).squeeze()
        output = self.fc(Y)
        return output

class ConvNet2(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32]
        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[1], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[1], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[1], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = F.adaptive_avg_pool2d(x, (1, 1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet3(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[2], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)

        x = F.adaptive_avg_pool2d(x, (1, 1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet4(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[3], latent_dim)
        self.latent_dim = latent_dim


    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet5(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()
        cs = [1, 32, 64, 128, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[4], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet6(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128, 256, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.conv6 = nn.Sequential(
            nn.Conv2d(cs[5], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[5], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.conv6(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet7(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128, 256, 256, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.conv6 = nn.Sequential(
            nn.Conv2d(cs[5], cs[6], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[6], cs[6], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[6], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.conv6(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet8(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128, 256, 256, 256, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.conv6 = nn.Sequential(
            nn.Conv2d(cs[5], cs[6], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[6], cs[6], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
        )
        self.conv7 = nn.Sequential(
            nn.Conv2d(cs[6], cs[7], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[7], cs[7], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[7], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.conv6(x)
        x = self.conv7(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet9(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128, 256, 256, 256, 256, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.conv6 = nn.Sequential(
            nn.Conv2d(cs[5], cs[6], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[6], cs[6], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
        )
        self.conv7 = nn.Sequential(
            nn.Conv2d(cs[6], cs[7], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[7], cs[7], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
        )
        self.conv8 = nn.Sequential(
            nn.Conv2d(cs[7], cs[8], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[8]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[8], cs[8], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[8]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[8], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.conv6(x)
        x = self.conv7(x)
        x = self.conv8(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x

class ConvNet10(nn.Module):
    def __init__(self, latent_dim = 10):
        super().__init__()

        cs = [1, 32, 64, 128, 256, 256, 256, 256, 256, 256]

        self.conv1 = nn.Sequential(
            nn.Conv2d(cs[0], cs[1], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[1]),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(cs[1], cs[2], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[2], cs[2], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[2]),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(cs[2], cs[3], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[3], cs[3], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[3]),
            nn.LeakyReLU(),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(cs[3], cs[4], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[4], cs[4], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[4]),
            nn.LeakyReLU(),
        )
        self.conv5 = nn.Sequential(
            nn.Conv2d(cs[4], cs[5], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[5], cs[5], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[5]),
            nn.LeakyReLU(),
        )
        self.conv6 = nn.Sequential(
            nn.Conv2d(cs[5], cs[6], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[6], cs[6], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[6]),
            nn.LeakyReLU(),
        )
        self.conv7 = nn.Sequential(
            nn.Conv2d(cs[6], cs[7], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[7], cs[7], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[7]),
            nn.LeakyReLU(),
        )
        self.conv8 = nn.Sequential(
            nn.Conv2d(cs[7], cs[8], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[8]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[8], cs[8], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[8]),
            nn.LeakyReLU(),
        )
        self.conv9 = nn.Sequential(
            nn.Conv2d(cs[8], cs[9], 3, 2, 1, bias=False),
            nn.BatchNorm2d(cs[9]),
            nn.LeakyReLU(),
            nn.Conv2d(cs[9], cs[9], 3, 1, 1, bias=False),
            nn.BatchNorm2d(cs[9]),
            nn.LeakyReLU(),
        )
        self.fc = nn.Linear(cs[9], latent_dim)
        self.latent_dim = latent_dim

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.conv6(x)
        x = self.conv7(x)
        x = self.conv8(x)
        x = self.conv9(x)
        x = F.adaptive_avg_pool2d(x, (1,1)).squeeze()
        x = self.fc(x)
        return x