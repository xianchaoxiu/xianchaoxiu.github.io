import numpy as np
import matplotlib.pyplot as plt
# import tsne
from sklearn.manifold import TSNE
# load data
def plot_tsne(tsne_data, label, plot, title, show_legend=True):
    classes = list(set(label))
    scatter_plots = []  # list to hold scatter plot for each class
    class_labels = []  # list to hold class labels
    cmap = plt.cm.get_cmap('nipy_spectral', len(classes))  # 'nipy_spectral' is an example of colormap which can give more distinct colors
    # get more distinct colors
    colors = cmap(np.linspace(0, 1, len(classes)))

    for class_id, color in zip(classes, colors):
        idx = (label == class_id)
        # show bigger tsne points
        scatter_plot = plot.scatter(tsne_data[idx, 0], tsne_data[idx, 1], s=150, color=color, alpha=1.0)
        scatter_plots.append(scatter_plot)
        class_labels.append(str(class_id))

    # make legend under the tsne plot and show bigger and hind border
    if show_legend:
        legend = plot.legend(scatter_plots, class_labels, loc='upper left',
                                bbox_to_anchor=(0.0, 1.2), shadow=False, ncol=10, fontsize=48, markerscale=2.0)
        frame = legend.get_frame()
        frame.set_facecolor('white')

    plot.set_title(title, fontsize=60, y=-0.01)


dataset_name = "NoisyFashionMNIST"
# load data
cca_tsne = np.load(f"./Figures/{dataset_name}-CCA-TSNE.npy")
cca_label = np.load(f"./Figures/{dataset_name}-CCA-Label.npy")

dcca_tsne = np.load(f"./Figures/{dataset_name}-DCCA-TSNE.npy")
dcca_label = np.load(f"./Figures/{dataset_name}-DCCA-Label.npy")

convcca_tsne = np.load(f"./Figures/{dataset_name}-ConvCCA-TSNE.npy")
convcca_label = np.load(f"./Figures/{dataset_name}-ConvCCA-Label.npy")

rescca_tsne = np.load(f"./Figures/{dataset_name}-ResCCA-TSNE.npy")
rescca_label = np.load(f"./Figures/{dataset_name}-ResCCA-Label.npy")

# plot tsne with bigger points and legend
# plot tsne with bigger points and legend
fig, axs = plt.subplots(nrows=1, ncols=4, figsize=(12 * 5, 12))  # change to 1 row and 4 columns

# make space between subplot bigger
plt.subplots_adjust(wspace=0.5, hspace=0.5)

# plot tsne and hide axis
plot_tsne(cca_tsne, cca_label, axs[0], "CCA", show_legend=True)
axs[0].axis('off')
axs[0].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(dcca_tsne, dcca_label, axs[1], "DCCA", show_legend=False)
axs[1].axis('off')
axs[1].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(convcca_tsne, convcca_label, axs[2], "ConvCCA", show_legend=False)
axs[2].axis('off')
axs[2].title.set_position([.5, -0.1])  # move title to below the plot

plot_tsne(rescca_tsne, rescca_label, axs[3], "ResCCA", show_legend=False)
axs[3].axis('off')
axs[3].title.set_position([.5, -0.1])  # move title to below the plot

# save to svg
#plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.svg", bbox_inches='tight', pad_inches=0)

# save to png more clear
plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.png", bbox_inches='tight', pad_inches=0, dpi=300)
plt.savefig(f"./Figures/{dataset_name}-Plot-TSNE.pdf", bbox_inches='tight', pad_inches=0)
plt.show()
